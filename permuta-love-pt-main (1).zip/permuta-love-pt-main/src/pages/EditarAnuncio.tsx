
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Save, X } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { ImageUpload } from '@/components/ImageUpload';

interface Categoria {
  id: string;
  nome: string;
  icone: string;
}

interface AnuncioForm {
  titulo: string;
  descricao: string;
  preco_xs: number;
  categoria_id: string;
  estado: string;
  localizacao: string;
  aceita_troca: boolean;
  aceita_euros: boolean;
}

const EditarAnuncio = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user, profile } = useAuth();
  const { toast } = useToast();
  
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [categorias, setCategorias] = useState<Categoria[]>([]);
  const [imagens, setImagens] = useState<string[]>([]);
  const [formData, setFormData] = useState<AnuncioForm>({
    titulo: '',
    descricao: '',
    preco_xs: 0,
    categoria_id: '',
    estado: 'novo',
    localizacao: '',
    aceita_troca: false,
    aceita_euros: false
  });

  const estados = [
    { value: 'novo', label: 'Novo' },
    { value: 'como_novo', label: 'Como Novo' },
    { value: 'usado_bom', label: 'Usado - Bom Estado' },
    { value: 'usado_razoavel', label: 'Usado - Estado Razoável' },
    { value: 'usado_mau', label: 'Usado - Mau Estado' }
  ];

  useEffect(() => {
    if (!user) {
      navigate('/auth');
      return;
    }
    
    loadCategorias();
    if (id) {
      loadAnuncio();
    }
  }, [user, id, navigate]);

  const loadCategorias = async () => {
    const { data } = await supabase
      .from('categorias')
      .select('*')
      .eq('ativa', true)
      .order('nome');
    
    if (data) setCategorias(data);
  };

  const loadAnuncio = async () => {
    if (!id || !profile) return;
    
    setLoading(true);
    
    // Carregar dados do anúncio
    const { data, error } = await supabase
      .from('anuncios')
      .select('*')
      .eq('id', id)
      .eq('utilizador_id', profile.id)
      .single();

    if (error) {
      toast({
        title: "Erro",
        description: "Anúncio não encontrado ou não tem permissões para editá-lo",
        variant: "destructive"
      });
      navigate('/dashboard');
      return;
    }

    if (data) {
      setFormData({
        titulo: data.titulo,
        descricao: data.descricao,
        preco_xs: data.preco_xs,
        categoria_id: data.categoria_id || '',
        estado: data.estado || 'novo',
        localizacao: data.localizacao || '',
        aceita_troca: data.aceita_troca,
        aceita_euros: data.aceita_euros
      });
    }

    // Carregar imagens do anúncio
    const { data: imagensData } = await supabase
      .from('anuncios_imagens')
      .select('url')
      .eq('anuncio_id', id)
      .order('ordem');

    if (imagensData) {
      setImagens(imagensData.map(img => img.url));
    }
    
    setLoading(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!profile || !id) return;
    
    setSaving(true);

    try {
      // Atualizar dados do anúncio
      const { error: anuncioError } = await supabase
        .from('anuncios')
        .update({
          titulo: formData.titulo,
          descricao: formData.descricao,
          preco_xs: formData.preco_xs,
          categoria_id: formData.categoria_id || null,
          estado: formData.estado,
          localizacao: formData.localizacao,
          aceita_troca: formData.aceita_troca,
          aceita_euros: formData.aceita_euros,
          updated_at: new Date().toISOString()
        })
        .eq('id', id);

      if (anuncioError) {
        toast({
          title: "Erro",
          description: "Erro ao atualizar anúncio. Tente novamente.",
          variant: "destructive"
        });
        return;
      }

      // Atualizar imagens - remover todas as existentes e adicionar as novas
      await supabase
        .from('anuncios_imagens')
        .delete()
        .eq('anuncio_id', id);

      // Adicionar novas imagens
      if (imagens.length > 0) {
        const imagensData = imagens.map((url, index) => ({
          anuncio_id: id,
          url,
          ordem: index
        }));

        const { error: imagensError } = await supabase
          .from('anuncios_imagens')
          .insert(imagensData);

        if (imagensError) {
          console.error('Erro ao atualizar imagens:', imagensError);
          // Não bloquear a atualização por causa das imagens
        }
      }

      toast({
        title: "Sucesso!",
        description: "Anúncio atualizado com sucesso"
      });

      navigate(`/anuncio/${id}`);
    } catch (error) {
      console.error('Erro ao atualizar anúncio:', error);
      toast({
        title: "Erro",
        description: "Erro inesperado. Tente novamente.",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-subtle py-8">
        <div className="container mx-auto px-4 max-w-2xl">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-muted rounded w-64" />
            <div className="h-96 bg-muted rounded" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-subtle py-8">
      <div className="container mx-auto px-4 max-w-2xl">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => navigate(`/anuncio/${id}`)}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar
          </Button>
          <h1 className="text-2xl font-bold text-primary">Editar Anúncio</h1>
        </div>

        <Card className="shadow-elegant">
          <CardHeader>
            <CardTitle>Informações do Anúncio</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Título */}
              <div className="space-y-2">
                <Label htmlFor="titulo">Título do Anúncio *</Label>
                <Input
                  id="titulo"
                  value={formData.titulo}
                  onChange={(e) => setFormData({ ...formData, titulo: e.target.value })}
                  placeholder="Ex: iPhone 14 Pro Max 256GB"
                  required
                />
              </div>

              {/* Descrição */}
              <div className="space-y-2">
                <Label htmlFor="descricao">Descrição *</Label>
                <Textarea
                  id="descricao"
                  value={formData.descricao}
                  onChange={(e) => setFormData({ ...formData, descricao: e.target.value })}
                  placeholder="Descreva o seu produto ou serviço..."
                  rows={5}
                  required
                />
              </div>

              {/* Preço e Categoria */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="preco">Preço (X$) *</Label>
                  <Input
                    id="preco"
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.preco_xs}
                    onChange={(e) => setFormData({ ...formData, preco_xs: parseFloat(e.target.value) || 0 })}
                    placeholder="0.00"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="categoria">Categoria</Label>
                  <Select value={formData.categoria_id} onValueChange={(value) => setFormData({ ...formData, categoria_id: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione uma categoria" />
                    </SelectTrigger>
                    <SelectContent>
                      {categorias.map((categoria) => (
                        <SelectItem key={categoria.id} value={categoria.id}>
                          {categoria.nome}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Estado e Localização */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="estado">Estado do Produto</Label>
                  <Select value={formData.estado} onValueChange={(value) => setFormData({ ...formData, estado: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {estados.map((estado) => (
                        <SelectItem key={estado.value} value={estado.value}>
                          {estado.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="localizacao">Localização</Label>
                  <Input
                    id="localizacao"
                    value={formData.localizacao}
                    onChange={(e) => setFormData({ ...formData, localizacao: e.target.value })}
                    placeholder="Ex: Lisboa, Porto..."
                  />
                </div>
              </div>

              {/* Método de Pagamento */}
              <div className="space-y-2">
                <Label>Método de Pagamento</Label>
                <div className="bg-muted/30 p-4 rounded-lg">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 bg-primary/20 rounded-full flex items-center justify-center">
                      <span className="text-primary text-sm font-bold">X$</span>
                    </div>
                    <div>
                      <p className="text-sm font-medium">Pagamento em X$</p>
                      <p className="text-xs text-muted-foreground">
                        Todas as transações são realizadas exclusivamente em X$
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Imagens */}
              <div className="space-y-2">
                <Label>Imagens do Anúncio</Label>
                <ImageUpload
                  images={imagens}
                  onImagesChange={setImagens}
                  maxImages={5}
                  anuncioId={id}
                />
              </div>

              {/* Botões */}
              <div className="flex gap-4 pt-4">
                <Button
                  type="submit"
                  disabled={saving}
                  className="flex-1 bg-gradient-primary"
                >
                  <Save className="w-4 h-4 mr-2" />
                  {saving ? 'Guardando...' : 'Guardar Alterações'}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => navigate(`/anuncio/${id}`)}
                  className="flex-1"
                >
                  <X className="w-4 h-4 mr-2" />
                  Cancelar
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default EditarAnuncio;
