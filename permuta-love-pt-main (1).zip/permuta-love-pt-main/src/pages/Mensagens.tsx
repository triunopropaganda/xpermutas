import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ArrowLeft, Send, MessageSquare, User, Eye } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';

interface Mensagem {
  id: string;
  mensagem: string;
  created_at: string;
  lida: boolean;
  remetente_id: string;
  destinatario_id: string;
  anuncio_id: string;
  remetente: { nome: string };
  destinatario: { nome: string };
}

interface Conversa {
  anuncio_id: string;
  anuncio_titulo: string;
  outro_utilizador_id: string;
  outro_utilizador_nome: string;
  ultima_mensagem: string;
  ultima_data: string;
  mensagens_nao_lidas: number;
}

const Mensagens = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { user, profile } = useAuth();
  const { toast } = useToast();
  
  const [conversas, setConversas] = useState<Conversa[]>([]);
  const [mensagens, setMensagens] = useState<Mensagem[]>([]);
  const [conversaSelecionada, setConversaSelecionada] = useState<Conversa | null>(null);
  const [novaMensagem, setNovaMensagem] = useState('');
  const [loading, setLoading] = useState(true);
  const [enviando, setEnviando] = useState(false);

  useEffect(() => {
    if (!user) {
      navigate('/auth');
      return;
    }
    if (profile) {
      loadConversas();
      const anuncioId = searchParams.get('anuncio');
      if (anuncioId) {
        // Aguardar o carregamento das conversas e depois selecionar
        setTimeout(() => {
          const conversa = conversas.find(c => c.anuncio_id === anuncioId);
          if (conversa) {
            selecionarConversa(conversa);
          }
        }, 1000);
      }
    }
  }, [user, profile, navigate, searchParams]);

  const loadConversas = async () => {
    if (!profile?.id) return;

    try {
      const { data, error } = await supabase
        .from('mensagens')
        .select(`
          anuncio_id,
          remetente_id,
          destinatario_id,
          mensagem,
          created_at,
          lida,
          anuncios!inner(titulo)
        `)
        .or(`remetente_id.eq.${profile.id},destinatario_id.eq.${profile.id}`)
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Buscar nomes dos perfis
      const profileIds = [...new Set([...data.map(m => m.remetente_id), ...data.map(m => m.destinatario_id)])];
      const { data: profiles } = await supabase
        .from('profiles')
        .select('id, nome')
        .in('id', profileIds);

      const profileMap = new Map(profiles?.map(p => [p.id, p.nome]) || []);

      // Agrupar mensagens por anúncio e outro utilizador
      const conversasMap = new Map<string, Conversa>();

      data?.forEach((mensagem: any) => {
        const outroUtilizadorId = mensagem.remetente_id === profile.id 
          ? mensagem.destinatario_id 
          : mensagem.remetente_id;
        
        const outroUtilizadorNome = profileMap.get(outroUtilizadorId) || 'Utilizador';

        const chaveConversa = `${mensagem.anuncio_id}-${outroUtilizadorId}`;

        if (!conversasMap.has(chaveConversa)) {
          conversasMap.set(chaveConversa, {
            anuncio_id: mensagem.anuncio_id,
            anuncio_titulo: mensagem.anuncios.titulo,
            outro_utilizador_id: outroUtilizadorId,
            outro_utilizador_nome: outroUtilizadorNome,
            ultima_mensagem: mensagem.mensagem,
            ultima_data: mensagem.created_at,
            mensagens_nao_lidas: 0
          });
        }

        const conversa = conversasMap.get(chaveConversa)!;

        // Contar mensagens não lidas (onde sou o destinatário)
        if (mensagem.destinatario_id === profile.id && !mensagem.lida) {
          conversa.mensagens_nao_lidas++;
        }

        // Atualizar com a mensagem mais recente
        if (new Date(mensagem.created_at) > new Date(conversa.ultima_data)) {
          conversa.ultima_mensagem = mensagem.mensagem;
          conversa.ultima_data = mensagem.created_at;
        }
      });

      setConversas(Array.from(conversasMap.values()));
    } catch (error) {
      console.error('Erro ao carregar conversas:', error);
      toast({
        title: "Erro",
        description: "Erro ao carregar conversas",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const selecionarConversa = async (conversa: Conversa) => {
    setConversaSelecionada(conversa);
    await loadMensagensDaConversa(conversa.anuncio_id, conversa.outro_utilizador_id);
    await marcarMensagensComoLidas(conversa.anuncio_id, conversa.outro_utilizador_id);
  };

  const loadMensagensDaConversa = async (anuncioId: string, outroUtilizadorId: string) => {
    if (!profile?.id) return;

    try {
      const { data, error } = await supabase
        .from('mensagens')
        .select(`
          id, mensagem, created_at, lida, remetente_id, destinatario_id, anuncio_id
        `)
        .eq('anuncio_id', anuncioId)
        .or(`and(remetente_id.eq.${profile.id},destinatario_id.eq.${outroUtilizadorId}),and(remetente_id.eq.${outroUtilizadorId},destinatario_id.eq.${profile.id})`)
        .order('created_at', { ascending: true });

      if (error) throw error;
      
      // Buscar perfis dos remetentes e destinatários
      const profileIds = [...new Set([...data.map(m => m.remetente_id), ...data.map(m => m.destinatario_id)])];
      const { data: profiles } = await supabase
        .from('profiles')
        .select('id, nome')
        .in('id', profileIds);

      const profileMap = new Map(profiles?.map(p => [p.id, p]) || []);

      const mensagensComPerfis = data.map(mensagem => ({
        ...mensagem,
        remetente: { nome: profileMap.get(mensagem.remetente_id)?.nome || 'Utilizador' },
        destinatario: { nome: profileMap.get(mensagem.destinatario_id)?.nome || 'Utilizador' }
      }));

      setMensagens(mensagensComPerfis);
    } catch (error) {
      console.error('Erro ao carregar mensagens:', error);
    }
  };

  const marcarMensagensComoLidas = async (anuncioId: string, outroUtilizadorId: string) => {
    if (!profile?.id) return;

    try {
      await supabase
        .from('mensagens')
        .update({ lida: true })
        .eq('anuncio_id', anuncioId)
        .eq('remetente_id', outroUtilizadorId)
        .eq('destinatario_id', profile.id)
        .eq('lida', false);

      // Atualizar contador na conversa
      setConversas(prev => prev.map(c => 
        c.anuncio_id === anuncioId && c.outro_utilizador_id === outroUtilizadorId
          ? { ...c, mensagens_nao_lidas: 0 }
          : c
      ));
    } catch (error) {
      console.error('Erro ao marcar mensagens como lidas:', error);
    }
  };

  const enviarMensagem = async () => {
    if (!novaMensagem.trim() || !conversaSelecionada || !profile?.id) return;

    setEnviando(true);
    try {
      const { error } = await supabase
        .from('mensagens')
        .insert({
          anuncio_id: conversaSelecionada.anuncio_id,
          remetente_id: profile.id,
          destinatario_id: conversaSelecionada.outro_utilizador_id,
          mensagem: novaMensagem.trim()
        });

      if (error) throw error;

      setNovaMensagem('');
      await loadMensagensDaConversa(conversaSelecionada.anuncio_id, conversaSelecionada.outro_utilizador_id);
      await loadConversas();
    } catch (error) {
      console.error('Erro ao enviar mensagem:', error);
      toast({
        title: "Erro",
        description: "Erro ao enviar mensagem",
        variant: "destructive"
      });
    } finally {
      setEnviando(false);
    }
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-subtle">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-white/20 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate('/dashboard')}
              className="text-primary"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar ao Dashboard
            </Button>
            <div className="flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-primary" />
              <h1 className="text-xl font-bold text-primary">Mensagens</h1>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-200px)]">
          {/* Lista de Conversas */}
          <Card className="shadow-elegant">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5" />
                Conversas
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {loading ? (
                <div className="p-4">
                  <p className="text-sm text-muted-foreground">A carregar conversas...</p>
                </div>
              ) : conversas.length === 0 ? (
                <div className="p-4 text-center">
                  <p className="text-sm text-muted-foreground">Ainda não tem conversas</p>
                </div>
              ) : (
                <div className="max-h-[500px] overflow-y-auto">
                  {conversas.map((conversa, index) => (
                    <div
                      key={`${conversa.anuncio_id}-${conversa.outro_utilizador_id}`}
                      className={`p-4 border-b cursor-pointer hover:bg-muted/50 transition-colors ${
                        conversaSelecionada?.anuncio_id === conversa.anuncio_id && 
                        conversaSelecionada?.outro_utilizador_id === conversa.outro_utilizador_id
                          ? 'bg-primary/10 border-primary/20'
                          : ''
                      }`}
                      onClick={() => selecionarConversa(conversa)}
                    >
                      <div className="flex items-start gap-3">
                        <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                          <User className="w-4 h-4 text-primary" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-1">
                            <p className="text-sm font-medium truncate">
                              {conversa.outro_utilizador_nome}
                            </p>
                            {conversa.mensagens_nao_lidas > 0 && (
                              <Badge variant="destructive" className="text-xs">
                                {conversa.mensagens_nao_lidas}
                              </Badge>
                            )}
                          </div>
                          <p className="text-xs text-muted-foreground mb-1 truncate">
                            {conversa.anuncio_titulo}
                          </p>
                          <p className="text-xs text-muted-foreground truncate">
                            {conversa.ultima_mensagem}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Chat */}
          <div className="lg:col-span-2">
            {conversaSelecionada ? (
              <Card className="shadow-elegant h-full flex flex-col">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <div>
                      <p className="text-lg">{conversaSelecionada.outro_utilizador_nome}</p>
                      <p className="text-sm text-muted-foreground font-normal">
                        {conversaSelecionada.anuncio_titulo}
                      </p>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => navigate(`/anuncio/${conversaSelecionada.anuncio_id}`)}
                    >
                      <Eye className="w-4 h-4 mr-2" />
                      Ver Anúncio
                    </Button>
                  </CardTitle>
                </CardHeader>
                
                <Separator />
                
                {/* Mensagens */}
                <CardContent className="flex-1 p-4 overflow-y-auto max-h-[400px]">
                  <div className="space-y-4">
                    {mensagens.map((mensagem) => (
                      <div
                        key={mensagem.id}
                        className={`flex ${
                          mensagem.remetente_id === profile?.id ? 'justify-end' : 'justify-start'
                        }`}
                      >
                        <div
                          className={`max-w-[70%] p-3 rounded-lg ${
                            mensagem.remetente_id === profile?.id
                              ? 'bg-primary text-primary-foreground'
                              : 'bg-muted'
                          }`}
                        >
                          <p className="text-sm">{mensagem.mensagem}</p>
                          <p className={`text-xs mt-1 ${
                            mensagem.remetente_id === profile?.id
                              ? 'text-primary-foreground/70'
                              : 'text-muted-foreground'
                          }`}>
                            {new Date(mensagem.created_at).toLocaleString('pt-PT')}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
                
                <Separator />
                
                {/* Input de nova mensagem */}
                <div className="p-4">
                  <div className="flex gap-2">
                    <Input
                      placeholder="Escreva a sua mensagem..."
                      value={novaMensagem}
                      onChange={(e) => setNovaMensagem(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && enviarMensagem()}
                      disabled={enviando}
                    />
                    <Button
                      onClick={enviarMensagem}
                      disabled={!novaMensagem.trim() || enviando}
                      className="bg-gradient-primary"
                    >
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            ) : (
              <Card className="shadow-elegant h-full flex items-center justify-center">
                <CardContent className="text-center">
                  <MessageSquare className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">
                    Selecione uma conversa para começar a chat
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Mensagens;