import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Search, 
  Filter, 
  Heart, 
  MapPin, 
  Clock,
  Star,
  Plus,
  Grid,
  List,
  SlidersHorizontal,
  ArrowLeft,
  Home
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

interface Anuncio {
  id: string;
  titulo: string;
  descricao: string;
  preco_xs: number;
  localizacao: string;
  estado: string;
  aceita_troca: boolean;
  aceita_euros: boolean;
  views: number;
  favoritos: number;
  destaque: boolean;
  created_at: string;
  categoria?: {
    nome: string;
    icone: string;
  } | null;
  utilizador?: {
    nome: string;
  } | null;
  imagens?: { url: string }[] | null;
}

interface Categoria {
  id: string;
  nome: string;
  icone: string;
}

const Marketplace = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [anuncios, setAnuncios] = useState<Anuncio[]>([]);
  const [categorias, setCategorias] = useState<Categoria[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [filtros, setFiltros] = useState({
    estado: '',
    preco_min: '',
    preco_max: '',
    aceita_troca: false,
    aceita_euros: false
  });

  useEffect(() => {
    loadCategorias();
    loadAnuncios();
  }, [selectedCategory, searchTerm, filtros]);

  const loadCategorias = async () => {
    const { data } = await supabase
      .from('categorias')
      .select('*')
      .eq('ativa', true)
      .order('nome');
    
    if (data) setCategorias(data);
  };

  const loadAnuncios = async () => {
    setLoading(true);
    
    let query = supabase
      .from('anuncios')
      .select(`
        *,
        categoria:categorias(nome, icone),
        utilizador:profiles!fk_anuncios_utilizador(nome),
        imagens:anuncios_imagens(url)
      `)
      .eq('disponivel', true)
      .order('destaque', { ascending: false })
      .order('created_at', { ascending: false });

    // Filtros
    if (selectedCategory && selectedCategory !== 'all') {
      query = query.eq('categoria_id', selectedCategory);
    }

    if (searchTerm) {
      query = query.or(`titulo.ilike.%${searchTerm}%,descricao.ilike.%${searchTerm}%`);
    }

    if (filtros.estado) {
      query = query.eq('estado', filtros.estado);
    }

    if (filtros.preco_min) {
      query = query.gte('preco_xs', parseFloat(filtros.preco_min));
    }

    if (filtros.preco_max) {
      query = query.lte('preco_xs', parseFloat(filtros.preco_max));
    }

    if (filtros.aceita_troca) {
      query = query.eq('aceita_troca', true);
    }

    if (filtros.aceita_euros) {
      query = query.eq('aceita_euros', true);
    }

    const { data } = await query;
    
    if (data) setAnuncios(data as unknown as Anuncio[]);
    setLoading(false);
  };

  const toggleFavorito = async (anuncioId: string) => {
    if (!user) {
      navigate('/auth');
      return;
    }

    // Implementar toggle favorito
    console.log('Toggle favorito', anuncioId);
  };

  const getImageUrl = (url: string) => {
    if (url.startsWith('photo-')) {
      return `https://images.unsplash.com/${url}?w=400&h=300&fit=crop`;
    }
    return url;
  };

  return (
    <div className="min-h-screen bg-gradient-subtle">
      {/* Header da página */}
      <div className="bg-white/80 backdrop-blur-md border-b border-white/20">
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate('/dashboard')}
                className="text-primary"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Dashboard
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate('/')}
                className="text-primary"
              >
                <Home className="w-4 h-4 mr-2" />
                Início
              </Button>
              <div>
                <h1 className="text-3xl font-bold text-primary">Marketplace</h1>
                <p className="text-muted-foreground">
                  Descubra produtos e serviços incríveis para trocar
                </p>
              </div>
            </div>
            
            <Button 
              onClick={() => navigate('/criar-anuncio')}
              className="bg-gradient-primary"
            >
              <Plus className="w-4 h-4 mr-2" />
              Criar Anúncio
            </Button>
          </div>

          {/* Barra de pesquisa e filtros */}
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                placeholder="Pesquisar anúncios..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-full lg:w-48">
                <SelectValue placeholder="Todas as categorias" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas as categorias</SelectItem>
                {categorias.map((categoria) => (
                  <SelectItem key={categoria.id} value={categoria.id}>
                    {categoria.nome}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setViewMode(viewMode === 'grid' ? 'list' : 'grid')}
              >
                {viewMode === 'grid' ? <List className="w-4 h-4" /> : <Grid className="w-4 h-4" />}
              </Button>
              
              <Button variant="outline" size="sm">
                <SlidersHorizontal className="w-4 h-4 mr-2" />
                Filtros
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[...Array(8)].map((_, i) => (
              <Card key={i} className="shadow-elegant animate-pulse">
                <div className="aspect-video bg-muted rounded-t-lg" />
                <CardContent className="p-4">
                  <div className="h-4 bg-muted rounded mb-2" />
                  <div className="h-3 bg-muted rounded mb-4 w-2/3" />
                  <div className="h-6 bg-muted rounded w-1/3" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <>
            {/* Resultados */}
            <div className="flex items-center justify-between mb-6">
              <p className="text-muted-foreground">
                {anuncios.length} anúncio{anuncios.length !== 1 ? 's' : ''} encontrado{anuncios.length !== 1 ? 's' : ''}
              </p>
            </div>

            {/* Grid de anúncios */}
            <div className={`grid gap-6 ${
              viewMode === 'grid' 
                ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' 
                : 'grid-cols-1'
            }`}>
              {anuncios.map((anuncio) => (
                <Card 
                  key={anuncio.id} 
                  className={`shadow-elegant hover:shadow-lg transition-all cursor-pointer group ${
                    anuncio.destaque ? 'ring-2 ring-primary/20' : ''
                  }`}
                  onClick={() => navigate(`/anuncio/${anuncio.id}`)}
                >
                  {/* Badge de destaque */}
                  {anuncio.destaque && (
                    <div className="absolute top-3 left-3 z-10">
                      <Badge className="bg-gradient-primary">
                        <Star className="w-3 h-3 mr-1" />
                        Destaque
                      </Badge>
                    </div>
                  )}

                  {/* Imagem */}
                  <div className="aspect-video bg-muted rounded-t-lg overflow-hidden relative">
                    {anuncio.imagens && anuncio.imagens.length > 0 ? (
                      <img 
                        src={getImageUrl(anuncio.imagens[0].url)} 
                        alt={anuncio.titulo}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-gradient-subtle">
                        <span className="text-muted-foreground">Sem imagem</span>
                      </div>
                    )}
                    
                    {/* Botão favorito */}
                    <Button
                      size="sm"
                      variant="secondary"
                      className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleFavorito(anuncio.id);
                      }}
                    >
                      <Heart className="w-4 h-4" />
                    </Button>
                  </div>

                  <CardContent className="p-4">
                    {/* Título e categoria */}
                    <div className="mb-2">
                      <h3 className="font-semibold text-primary line-clamp-2 mb-1">
                        {anuncio.titulo}
                      </h3>
                      {anuncio.categoria && (
                        <Badge variant="secondary" className="text-xs">
                          {anuncio.categoria.nome}
                        </Badge>
                      )}
                    </div>

                    {/* Preço */}
                    <div className="mb-3">
                      <span className="text-2xl font-bold text-primary">
                        {anuncio.preco_xs.toFixed(2)} X$
                      </span>
                      <div className="flex gap-1 mt-1">
                        {anuncio.aceita_troca && (
                          <Badge variant="outline" className="text-xs">Troca</Badge>
                        )}
                        {anuncio.aceita_euros && (
                          <Badge variant="outline" className="text-xs">€</Badge>
                        )}
                      </div>
                    </div>

                    {/* Info adicional */}
                    <div className="space-y-1 text-xs text-muted-foreground">
                      {anuncio.localizacao && (
                        <div className="flex items-center gap-1">
                          <MapPin className="w-3 h-3" />
                          {anuncio.localizacao}
                        </div>
                      )}
                      <div className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {new Date(anuncio.created_at).toLocaleDateString('pt-PT')}
                      </div>
                      <div className="flex items-center justify-between">
                        <span>{anuncio.views} visualizações</span>
                        <Badge variant="secondary" className="text-xs">
                          {anuncio.estado}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {anuncios.length === 0 && (
              <div className="text-center py-12">
                <div className="w-16 h-16 mx-auto mb-4 bg-muted rounded-full flex items-center justify-center">
                  <Search className="w-8 h-8 text-muted-foreground" />
                </div>
                <h3 className="text-lg font-semibold text-primary mb-2">
                  Nenhum anúncio encontrado
                </h3>
                <p className="text-muted-foreground mb-4">
                  Tente ajustar os seus filtros ou criar um novo anúncio
                </p>
                <Button onClick={() => navigate('/criar-anuncio')}>
                  <Plus className="w-4 h-4 mr-2" />
                  Criar Primeiro Anúncio
                </Button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default Marketplace;