import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, ArrowUp, ArrowDown, Plus, Eye } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

interface Transacao {
  id: string;
  tipo: string;
  valor: number;
  descricao: string;
  created_at: string;
  de_utilizador_id: string;
  para_utilizador_id: string;
  referencia_externa?: string;
}

const Extrato = () => {
  const navigate = useNavigate();
  const { user, profile } = useAuth();
  const { toast } = useToast();
  
  const [transacoes, setTransacoes] = useState<Transacao[]>([]);
  const [loading, setLoading] = useState(true);
  const [depositoValor, setDepositoValor] = useState('');
  const [processandoDeposito, setProcessandoDeposito] = useState(false);
  const [showDeposito, setShowDeposito] = useState(false);

  useEffect(() => {
    if (!user) {
      navigate('/auth');
      return;
    }
    loadTransacoes();
  }, [user, navigate]);

  const loadTransacoes = async () => {
    if (!profile) return;
    
    setLoading(true);
    
    const { data, error } = await supabase
      .from('transacoes_xs')
      .select('*')
      .or(`de_utilizador_id.eq.${profile.id},para_utilizador_id.eq.${profile.id}`)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Erro ao carregar transações:', error);
      toast({
        title: "Erro",
        description: "Erro ao carregar histórico de transações",
        variant: "destructive"
      });
    } else {
      setTransacoes(data || []);
    }
    
    setLoading(false);
  };

  const handleDeposito = async () => {
    if (!profile || !depositoValor) return;
    
    const valor = parseFloat(depositoValor);
    if (valor <= 0) {
      toast({
        title: "Erro",
        description: "Valor deve ser maior que zero",
        variant: "destructive"
      });
      return;
    }

    setProcessandoDeposito(true);

    try {
      const { data, error } = await supabase.functions.invoke('processar-transacao', {
        body: {
          tipo: 'deposito',
          valor: valor,
          descricao: `Depósito de ${valor} X$`,
          referencia_externa: `DEP_${Date.now()}`
        }
      });

      if (error) throw error;

      toast({
        title: "Sucesso!",
        description: `Depósito de ${valor} X$ realizado com sucesso`
      });

      setDepositoValor('');
      setShowDeposito(false);
      loadTransacoes();
      
      // Refresh profile to update balance
      window.location.reload();
      
    } catch (error: any) {
      console.error('Erro ao processar depósito:', error);
      toast({
        title: "Erro",
        description: error.message || "Erro ao processar depósito",
        variant: "destructive"
      });
    } finally {
      setProcessandoDeposito(false);
    }
  };

  const formatarTipo = (tipo: string) => {
    const tipos = {
      'deposito': 'Depósito',
      'compra': 'Compra',
      'venda': 'Venda',
      'transferencia': 'Transferência'
    };
    return tipos[tipo as keyof typeof tipos] || tipo;
  };

  const getTipoIcon = (transacao: Transacao) => {
    const isRecebido = transacao.para_utilizador_id === profile?.id;
    
    if (transacao.tipo === 'deposito') return <Plus className="w-4 h-4 text-green-600" />;
    if (isRecebido) return <ArrowDown className="w-4 h-4 text-green-600" />;
    return <ArrowUp className="w-4 h-4 text-red-600" />;
  };

  const getTipoColor = (transacao: Transacao) => {
    const isRecebido = transacao.para_utilizador_id === profile?.id;
    
    if (transacao.tipo === 'deposito') return 'bg-green-100 text-green-800';
    if (isRecebido) return 'bg-green-100 text-green-800';
    return 'bg-red-100 text-red-800';
  };

  const formatarValor = (transacao: Transacao) => {
    const isRecebido = transacao.para_utilizador_id === profile?.id;
    const sinal = (transacao.tipo === 'deposito' || isRecebido) ? '+' : '-';
    return `${sinal}${transacao.valor.toFixed(2)} X$`;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-subtle py-8">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-muted rounded w-64" />
            <div className="h-96 bg-muted rounded" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-subtle py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => navigate('/dashboard')}
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar
            </Button>
            <h1 className="text-2xl font-bold text-primary">Extrato da Carteira</h1>
          </div>

          <Dialog open={showDeposito} onOpenChange={setShowDeposito}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-primary">
                <Plus className="w-4 h-4 mr-2" />
                Adicionar Fundos
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Adicionar Fundos à Carteira</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="valor">Valor (X$)</Label>
                  <Input
                    id="valor"
                    type="number"
                    min="0"
                    step="0.01"
                    value={depositoValor}
                    onChange={(e) => setDepositoValor(e.target.value)}
                    placeholder="0.00"
                  />
                </div>
                <Button 
                  onClick={handleDeposito}
                  disabled={processandoDeposito || !depositoValor}
                  className="w-full bg-gradient-primary"
                >
                  {processandoDeposito ? 'Processando...' : 'Adicionar Fundos'}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Saldo Atual */}
        <Card className="shadow-elegant mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center">
                <span className="text-primary text-sm font-bold">X$</span>
              </div>
              Saldo da Carteira
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-primary">
              {profile?.saldo_xs?.toFixed(2) || '0.00'} X$
            </div>
            <p className="text-muted-foreground mt-2">
              Saldo disponível para compras e transferências
            </p>
          </CardContent>
        </Card>

        {/* Histórico de Transações */}
        <Card className="shadow-elegant">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Eye className="w-5 h-5" />
              Histórico de Transações
            </CardTitle>
          </CardHeader>
          <CardContent>
            {transacoes.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <p>Nenhuma transação encontrada</p>
                <p className="text-sm mt-1">Comece adicionando fundos à sua carteira</p>
              </div>
            ) : (
              <div className="space-y-4">
                {transacoes.map((transacao) => (
                  <div 
                    key={transacao.id}
                    className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/30 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      {getTipoIcon(transacao)}
                      <div>
                        <div className="font-medium">{transacao.descricao}</div>
                        <div className="text-sm text-muted-foreground">
                          {new Date(transacao.created_at).toLocaleDateString('pt-PT', {
                            day: '2-digit',
                            month: '2-digit',
                            year: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-3">
                      <Badge className={getTipoColor(transacao)}>
                        {formatarTipo(transacao.tipo)}
                      </Badge>
                      <div className="font-bold text-right">
                        {formatarValor(transacao)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Extrato;