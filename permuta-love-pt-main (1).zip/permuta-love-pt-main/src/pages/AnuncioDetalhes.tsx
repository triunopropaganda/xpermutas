import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Textarea } from '@/components/ui/textarea';
import { 
  ArrowLeft, 
  Heart,
  Share2,
  MessageCircle,
  MapPin,
  Clock,
  Eye,
  User,
  Shield,
  ChevronLeft,
  ChevronRight,
  Send,
  Edit,
  Trash2,
  ShoppingCart,
  Wallet
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';

interface AnuncioDetalhado {
  id: string;
  titulo: string;
  descricao: string;
  preco_xs: number;
  localizacao: string;
  estado: string;
  aceita_troca: boolean;
  aceita_euros: boolean;
  views: number;
  favoritos: number;
  destaque: boolean;
  disponivel: boolean;
  created_at: string;
  categoria: {
    nome: string;
    icone: string;
  } | null;
  utilizador: {
    id: string;
    nome: string;
    verificado: boolean;
    created_at: string;
  } | null;
  imagens: { url: string; ordem: number }[];
}

const AnuncioDetalhes = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user, profile } = useAuth();
  const { toast } = useToast();
  
  const [anuncio, setAnuncio] = useState<AnuncioDetalhado | null>(null);
  const [loading, setLoading] = useState(true);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isFavorited, setIsFavorited] = useState(false);
  const [showMessageForm, setShowMessageForm] = useState(false);
  const [mensagem, setMensagem] = useState('');
  const [sendingMessage, setSendingMessage] = useState(false);
  const [processandoCompra, setProcessandoCompra] = useState(false);

  useEffect(() => {
    if (id) {
      loadAnuncio();
      incrementViews();
      if (user) checkFavorite();
    }
  }, [id, user]);

  const loadAnuncio = async () => {
    if (!id) return;
    
    const { data, error } = await supabase
      .from('anuncios')
      .select(`
        *,
        categoria:categorias(nome, icone),
        utilizador:profiles!fk_anuncios_utilizador(id, nome, verificado, created_at),
        imagens:anuncios_imagens(url, ordem)
      `)
      .eq('id', id)
      .single();

    if (error) {
      console.error('Erro ao carregar anúncio:', error);
      navigate('/marketplace');
      return;
    }

    if (data) {
      // Ordenar imagens por ordem
      const imagensOrdenadas = data.imagens?.sort((a, b) => a.ordem - b.ordem) || [];
      setAnuncio({ ...data, imagens: imagensOrdenadas } as unknown as AnuncioDetalhado);
    }
    
    setLoading(false);
  };

  const incrementViews = async () => {
    if (!id) return;
    
    try {
      await supabase.rpc('incrementar_views_anuncio', { anuncio_uuid: id });
    } catch (error) {
      console.error('Erro ao incrementar views:', error);
    }
  };

  const checkFavorite = async () => {
    if (!id || !profile) return;
    
    const { data } = await supabase
      .from('favoritos')
      .select('id')
      .eq('anuncio_id', id)
      .eq('utilizador_id', profile.id)
      .maybeSingle();
    
    setIsFavorited(!!data);
  };

  const toggleFavorite = async () => {
    if (!user || !profile || !anuncio) {
      navigate('/auth');
      return;
    }

    try {
      if (isFavorited) {
        await supabase
          .from('favoritos')
          .delete()
          .eq('anuncio_id', anuncio.id)
          .eq('utilizador_id', profile.id);
        
        setIsFavorited(false);
        toast({
          title: "Removido dos favoritos",
          description: "Anúncio removido da sua lista de favoritos"
        });
      } else {
        await supabase
          .from('favoritos')
          .insert({
            anuncio_id: anuncio.id,
            utilizador_id: profile.id
          });
        
        setIsFavorited(true);
        toast({
          title: "Adicionado aos favoritos",
          description: "Anúncio adicionado à sua lista de favoritos"
        });
      }
    } catch (error) {
      console.error('Erro ao alterar favorito:', error);
      toast({
        title: "Erro",
        description: "Erro ao alterar favorito. Tente novamente.",
        variant: "destructive"
      });
    }
  };

  const sendMessage = async () => {
    if (!user || !profile || !anuncio || !mensagem.trim()) return;
    
    if (!anuncio.utilizador) {
      toast({
        title: "Erro",
        description: "Utilizador do anúncio não encontrado",
        variant: "destructive"
      });
      return;
    }

    setSendingMessage(true);

    try {
      await supabase
        .from('mensagens')
        .insert({
          anuncio_id: anuncio.id,
          remetente_id: profile.id,
          destinatario_id: anuncio.utilizador.id,
          mensagem: mensagem.trim()
        });

      toast({
        title: "Mensagem enviada!",
        description: "A sua mensagem foi enviada com sucesso"
      });

      setMensagem('');
      setShowMessageForm(false);
    } catch (error) {
      console.error('Erro ao enviar mensagem:', error);
      toast({
        title: "Erro",
        description: "Erro ao enviar mensagem. Tente novamente.",
        variant: "destructive"
      });
    } finally {
      setSendingMessage(false);
    }
  };

  const toggleDisponivel = async (anuncioId: string, disponivel: boolean) => {
    if (!user || !profile) {
      toast({
        title: "Erro",
        description: "Deve estar autenticado para realizar esta ação",
        variant: "destructive"
      });
      return;
    }
    
    try {
      console.log('Chamando função toggle_anuncio_disponibilidade:', { 
        anuncioId, 
        disponivel, 
        profileId: profile.id 
      });
      
      const { data, error } = await supabase.rpc('toggle_anuncio_disponibilidade', {
        anuncio_id: anuncioId,
        novo_status: disponivel,
        utilizador_profile_id: profile.id
      });

      console.log('Resultado da função:', { data, error });

      if (error) {
        console.error('Erro na função RPC:', error);
        throw error;
      }

      const result = data as { success: boolean; error?: string; message?: string };

      if (!result.success) {
        toast({
          title: "Erro",
          description: result.error || "Erro ao alterar anúncio",
          variant: "destructive"
        });
        return;
      }

      // Atualizar estado local
      if (anuncio) {
        setAnuncio({ ...anuncio, disponivel });
      }

      toast({
        title: "Sucesso",
        description: result.message || (disponivel ? "Anúncio reativado" : "Anúncio pausado")
      });
    } catch (error) {
      console.error('Erro ao alterar disponibilidade:', error);
      toast({
        title: "Erro",
        description: "Erro ao alterar anúncio. Tente novamente.",
        variant: "destructive"
      });
    }
  };

  const deleteAnuncio = async (anuncioId: string) => {
    if (!confirm('Tem a certeza que deseja eliminar este anúncio? Esta ação não pode ser revertida.')) {
      return;
    }

    try {
      const { error } = await supabase
        .from('anuncios')
        .delete()
        .eq('id', anuncioId);

      if (error) throw error;

      toast({
        title: "Anúncio eliminado",
        description: "O seu anúncio foi eliminado com sucesso"
      });

      navigate('/marketplace');
    } catch (error) {
      console.error('Erro ao eliminar anúncio:', error);
      toast({
        title: "Erro",
        description: "Erro ao eliminar anúncio. Tente novamente.",
        variant: "destructive"
      });
    }
  };

  const getImageUrl = (url: string) => {
    if (url.startsWith('photo-')) {
      return `https://images.unsplash.com/${url}?w=800&h=600&fit=crop`;
    }
    return url;
  };

  const nextImage = () => {
    if (anuncio && anuncio.imagens.length > 0) {
      setCurrentImageIndex((prev) => (prev + 1) % anuncio.imagens.length);
    }
  };

  const prevImage = () => {
    if (anuncio && anuncio.imagens.length > 0) {
      setCurrentImageIndex((prev) => 
        prev === 0 ? anuncio.imagens.length - 1 : prev - 1
      );
    }
  };

  const comprarProduto = async () => {
    if (!user || !profile || !anuncio) {
      navigate('/auth');
      return;
    }

    if (!anuncio.utilizador) {
      toast({
        title: "Erro",
        description: "Informações do vendedor não encontradas",
        variant: "destructive"
      });
      return;
    }

    if (profile.saldo_xs < anuncio.preco_xs) {
      toast({
        title: "Saldo insuficiente",
        description: `Precisa de ${anuncio.preco_xs.toFixed(2)} X$ mas tem apenas ${profile.saldo_xs.toFixed(2)} X$`,
        variant: "destructive"
      });
      return;
    }

    setProcessandoCompra(true);

    try {
      const { data, error } = await supabase.functions.invoke('processar-transacao', {
        body: {
          tipo: 'compra',
          valor: anuncio.preco_xs,
          para_utilizador_id: anuncio.utilizador.id,
          descricao: `Compra: ${anuncio.titulo}`,
          referencia_externa: `COMPRA_${anuncio.id}_${Date.now()}`
        }
      });

      if (error) throw error;

      // Marcar anúncio como vendido (indisponível)
      await supabase
        .from('anuncios')
        .update({ disponivel: false })
        .eq('id', anuncio.id);

      toast({
        title: "Compra realizada com sucesso!",
        description: `Produto "${anuncio.titulo}" comprado por ${anuncio.preco_xs.toFixed(2)} X$`
      });

      // Atualizar anúncio local
      setAnuncio({ ...anuncio, disponivel: false });
      
      // Redirecionar para extrato
      setTimeout(() => {
        navigate('/extrato');
      }, 2000);

    } catch (error: any) {
      console.error('Erro ao processar compra:', error);
      toast({
        title: "Erro na compra",
        description: error.message || "Erro ao processar compra. Tente novamente.",
        variant: "destructive"
      });
    } finally {
      setProcessandoCompra(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-subtle py-8">
        <div className="container mx-auto px-4 max-w-6xl">
          <div className="animate-pulse space-y-8">
            <div className="h-8 bg-muted rounded w-64" />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="aspect-video bg-muted rounded-lg" />
              <div className="space-y-4">
                <div className="h-8 bg-muted rounded w-3/4" />
                <div className="h-6 bg-muted rounded w-1/2" />
                <div className="h-32 bg-muted rounded" />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!anuncio) {
    return (
      <div className="min-h-screen bg-gradient-subtle flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-primary mb-2">Anúncio não encontrado</h1>
          <p className="text-muted-foreground mb-4">O anúncio que procura não existe ou foi removido.</p>
          <Button onClick={() => navigate('/marketplace')}>
            Voltar ao Marketplace
          </Button>
        </div>
      </div>
    );
  }

  const isOwner = profile && anuncio.utilizador && profile.id === anuncio.utilizador.id;

  return (
    <div className="min-h-screen bg-gradient-subtle py-8">
      <div className="container mx-auto px-4 max-w-6xl">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => navigate('/marketplace')}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar
          </Button>
          <div className="flex items-center gap-2">
            {anuncio.destaque && (
              <Badge className="bg-gradient-primary">Destaque</Badge>
            )}
            {anuncio.categoria && (
              <Badge variant="secondary">{anuncio.categoria.nome}</Badge>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Imagens */}
          <div className="lg:col-span-2">
            <Card className="shadow-elegant overflow-hidden">
              <div className="relative">
                {anuncio.imagens.length > 0 ? (
                  <>
                    <div className="aspect-video bg-muted">
                      <img
                        src={getImageUrl(anuncio.imagens[currentImageIndex].url)}
                        alt={anuncio.titulo}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    
                    {anuncio.imagens.length > 1 && (
                      <>
                        <Button
                          variant="secondary"
                          size="sm"
                          className="absolute left-3 top-1/2 transform -translate-y-1/2"
                          onClick={prevImage}
                        >
                          <ChevronLeft className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="secondary"
                          size="sm"
                          className="absolute right-3 top-1/2 transform -translate-y-1/2"
                          onClick={nextImage}
                        >
                          <ChevronRight className="w-4 h-4" />
                        </Button>
                        
                        <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2">
                          <div className="flex gap-2">
                            {anuncio.imagens.map((_, index) => (
                              <button
                                key={index}
                                className={`w-2 h-2 rounded-full transition-all ${
                                  index === currentImageIndex ? 'bg-white' : 'bg-white/50'
                                }`}
                                onClick={() => setCurrentImageIndex(index)}
                              />
                            ))}
                          </div>
                        </div>
                      </>
                    )}
                  </>
                ) : (
                  <div className="aspect-video bg-gradient-subtle flex items-center justify-center">
                    <span className="text-muted-foreground">Sem imagens</span>
                  </div>
                )}
              </div>
              
              {/* Thumbnails */}
              {anuncio.imagens.length > 1 && (
                <CardContent className="p-4">
                  <div className="flex gap-2 overflow-x-auto">
                    {anuncio.imagens.map((imagem, index) => (
                      <button
                        key={index}
                        className={`flex-shrink-0 w-20 h-16 rounded border-2 transition-all ${
                          index === currentImageIndex ? 'border-primary' : 'border-transparent'
                        }`}
                        onClick={() => setCurrentImageIndex(index)}
                      >
                        <img
                          src={getImageUrl(imagem.url)}
                          alt={`Thumbnail ${index + 1}`}
                          className="w-full h-full object-cover rounded"
                        />
                      </button>
                    ))}
                  </div>
                </CardContent>
              )}
            </Card>

            {/* Descrição */}
            <Card className="shadow-elegant mt-6">
              <CardHeader>
                <CardTitle>Descrição</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground whitespace-pre-wrap">
                  {anuncio.descricao}
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Informações principais */}
            <Card className="shadow-elegant">
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <div>
                    <h1 className="text-2xl font-bold text-primary mb-2">
                      {anuncio.titulo}
                    </h1>
                    <div className="text-3xl font-bold text-primary">
                      {anuncio.preco_xs.toFixed(2)} X$
                    </div>
                    <div className="flex gap-2 mt-2">
                      {anuncio.aceita_troca && (
                        <Badge variant="outline">Aceita Trocas</Badge>
                      )}
                      {anuncio.aceita_euros && (
                        <Badge variant="outline">Aceita Euros</Badge>
                      )}
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-3 text-sm">
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Estado:</span>
                      <Badge variant="secondary">{anuncio.estado}</Badge>
                    </div>
                    
                    {anuncio.localizacao && (
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-muted-foreground" />
                        <span>{anuncio.localizacao}</span>
                      </div>
                    )}
                    
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-muted-foreground" />
                      <span>{new Date(anuncio.created_at).toLocaleDateString('pt-PT')}</span>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Eye className="w-4 h-4 text-muted-foreground" />
                      <span>{anuncio.views} visualizações</span>
                    </div>
                  </div>

                  <Separator />

                   {/* Ações */}
                   {!isOwner ? (
                     <div className="space-y-3">
                       {anuncio.disponivel && (
                         <Button
                           className="w-full bg-green-600 hover:bg-green-700 text-white"
                           onClick={comprarProduto}
                           disabled={processandoCompra}
                         >
                           <ShoppingCart className="w-4 h-4 mr-2" />
                           {processandoCompra ? 'Processando...' : `Comprar por ${anuncio.preco_xs.toFixed(2)} X$`}
                         </Button>
                       )}
                       
                       <Button
                         className="w-full bg-gradient-primary"
                         onClick={() => setShowMessageForm(true)}
                       >
                         <MessageCircle className="w-4 h-4 mr-2" />
                         Contactar Vendedor
                       </Button>
                      
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          className="flex-1"
                          onClick={toggleFavorite}
                        >
                          <Heart className={`w-4 h-4 mr-2 ${isFavorited ? 'fill-current text-red-500' : ''}`} />
                          {isFavorited ? 'Remover' : 'Favorito'}
                        </Button>
                        
                        <Button variant="outline" size="icon">
                          <Share2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <p className="text-sm text-muted-foreground text-center mb-3">
                        Este é o seu anúncio
                      </p>
                      <Button
                        className="w-full bg-gradient-primary"
                        onClick={() => navigate(`/editar-anuncio/${anuncio.id}`)}
                      >
                        <Edit className="w-4 h-4 mr-2" />
                        Editar Anúncio
                      </Button>
                      
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          className="flex-1"
                          onClick={() => toggleDisponivel(anuncio.id, !anuncio.disponivel)}
                        >
                          {anuncio.disponivel ? 'Pausar' : 'Ativar'}
                        </Button>
                        
                        <Button 
                          variant="destructive" 
                          size="icon"
                          onClick={() => deleteAnuncio(anuncio.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Informações do vendedor */}
            {anuncio.utilizador && (
              <Card className="shadow-elegant">
                <CardHeader>
                  <CardTitle className="text-lg">Vendedor</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-gradient-primary rounded-full flex items-center justify-center">
                      <User className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{anuncio.utilizador.nome}</span>
                        {anuncio.utilizador.verificado && (
                          <Shield className="w-4 h-4 text-green-500" />
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Membro desde {new Date(anuncio.utilizador.created_at).getFullYear()}
                      </p>
                    </div>
                  </div>
                  
                  {!isOwner && (
                    <Button variant="outline" className="w-full" size="sm">
                      Ver Perfil
                    </Button>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Formulário de mensagem */}
            {showMessageForm && !isOwner && (
              <Card className="shadow-elegant">
                <CardHeader>
                  <CardTitle className="text-lg">Enviar Mensagem</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Textarea
                    placeholder="Escreva a sua mensagem..."
                    value={mensagem}
                    onChange={(e) => setMensagem(e.target.value)}
                    className="min-h-24"
                  />
                  <div className="flex gap-2">
                    <Button
                      onClick={sendMessage}
                      disabled={!mensagem.trim() || sendingMessage}
                      className="flex-1"
                    >
                      <Send className="w-4 h-4 mr-2" />
                      {sendingMessage ? 'Enviando...' : 'Enviar'}
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => setShowMessageForm(false)}
                    >
                      Cancelar
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnuncioDetalhes;