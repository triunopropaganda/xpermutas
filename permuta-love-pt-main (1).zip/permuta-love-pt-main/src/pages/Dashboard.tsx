import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { 
  Coins, 
  Plus, 
  Search, 
  FileText, 
  LogOut, 
  User, 
  Settings,
  TrendingUp,
  Shield,
  Gift,
  Eye,
  Edit,
  Trash2,
  MoreVertical,
  MapPin,
  Clock
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { MensagensWidget } from '@/components/MensagensWidget';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';

interface MeuAnuncio {
  id: string;
  titulo: string;
  preco_xs: number;
  views: number;
  favoritos: number;
  disponivel: boolean;
  destaque: boolean;
  created_at: string;
  categoria?: { nome: string };
  imagens?: { url: string }[];
}

const Dashboard = () => {
  const navigate = useNavigate();
  const { user, profile, signOut } = useAuth();
  const { toast } = useToast();
  const [meusAnuncios, setMeusAnuncios] = useState<MeuAnuncio[]>([]);
  const [loadingAnuncios, setLoadingAnuncios] = useState(true);

  useEffect(() => {
    if (!user) {
      navigate('/auth');
      return;
    }
    if (profile) {
      loadMeusAnuncios();
    }
  }, [user, profile, navigate]);

  if (!user) {
    return null;
  }

  const loadMeusAnuncios = async () => {
    if (!profile) return;
    
    setLoadingAnuncios(true);
    const { data } = await supabase
      .from('anuncios')
      .select(`
        id, titulo, preco_xs, views, favoritos, disponivel, destaque, created_at,
        categoria:categorias(nome),
        imagens:anuncios_imagens(url)
      `)
      .eq('utilizador_id', profile.id)
      .order('created_at', { ascending: false })
      .limit(5);
    
    if (data) setMeusAnuncios(data as unknown as MeuAnuncio[]);
    setLoadingAnuncios(false);
  };

  const toggleDisponivel = async (anuncioId: string, disponivel: boolean) => {
    const { error } = await supabase
      .from('anuncios')
      .update({ disponivel })
      .eq('id', anuncioId);

    if (error) {
      toast({
        title: "Erro",
        description: "Erro ao atualizar anúncio",
        variant: "destructive"
      });
      return;
    }

    loadMeusAnuncios();
    toast({
      title: "Sucesso",
      description: disponivel ? "Anúncio reativado" : "Anúncio pausado"
    });
  };

  const getImageUrl = (url: string) => {
    if (url.startsWith('photo-')) {
      return `https://images.unsplash.com/${url}?w=150&h=100&fit=crop`;
    }
    return url;
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-gradient-subtle">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-white/20 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-gradient-primary rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">X</span>
              </div>
              <h1 className="text-xl font-bold text-primary">XPermutas.pt</h1>
            </div>
            
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" className="text-primary">
                <User className="w-4 h-4 mr-2" />
                {profile?.nome || 'Utilizador'}
              </Button>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={handleSignOut}
                className="text-muted-foreground hover:text-destructive"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Sair
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Boas-vindas */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-primary mb-2">
            Bem-vindo, {profile?.nome}! 👋
          </h2>
          <p className="text-muted-foreground">
            Gerencie as suas permutas, saldo e explore novas oportunidades de negócio.
          </p>
        </div>

        {/* Cards de Saldo */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {/* Saldo X$ */}
          <Card className="border-primary/20 shadow-elegant">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Saldo X$ (Moeda de Permuta)
              </CardTitle>
              <Coins className="h-5 w-5 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-primary">
                {profile?.saldo_xs?.toFixed(2) || '0.00'} X$
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                1 X$ = 1 Euro
              </p>
            </CardContent>
          </Card>

          {/* Bónus em Euros */}
          <Card className="border-secondary/20 shadow-elegant">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Bónus em Euros
              </CardTitle>
              <Gift className="h-5 w-5 text-secondary" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-secondary">
                {profile?.bonus_euros?.toFixed(2) || '0.00'} €
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Para descontar em comissões
              </p>
            </CardContent>
          </Card>

          {/* Status da Conta */}
          <Card className="shadow-elegant">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Status da Conta
              </CardTitle>
              <Shield className="h-5 w-5 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="flex flex-col gap-2">
                <Badge variant={profile?.verificado ? "default" : "secondary"}>
                  {profile?.verificado ? 'Verificada' : 'Por Verificar'}
                </Badge>
                <Badge variant={profile?.ativo ? "default" : "destructive"}>
                  {profile?.ativo ? 'Ativa' : 'Inativa'}
                </Badge>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Ações Principais */}
        <div className="mb-8">
          <h3 className="text-xl font-semibold text-primary mb-4">Ações Rápidas</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Button 
              className="h-auto p-6 flex flex-col items-center gap-3 bg-gradient-primary hover:opacity-90"
              onClick={() => navigate('/criar-anuncio')}
            >
              <Plus className="w-8 h-8" />
              <span className="font-medium">Criar Anúncio</span>
            </Button>
            
            <Button 
              variant="outline" 
              className="h-auto p-6 flex flex-col items-center gap-3 border-primary/20"
              onClick={() => navigate('/marketplace')}
            >
              <Search className="w-8 h-8 text-primary" />
              <span className="font-medium text-primary">Procurar Ofertas</span>
            </Button>
            
            <Button 
              variant="outline" 
              className="h-auto p-6 flex flex-col items-center gap-3"
              onClick={() => navigate('/extrato')}
            >
              <FileText className="w-8 h-8 text-muted-foreground" />
              <span className="font-medium">O Meu Extrato</span>
            </Button>
            
            <Button 
              variant="outline" 
              className="h-auto p-6 flex flex-col items-center gap-3"
              onClick={() => navigate('/perfil')}
            >
              <Settings className="w-8 h-8 text-muted-foreground" />
              <span className="font-medium">Gerir Perfil</span>
            </Button>
          </div>
        </div>

        {/* Meus Anúncios */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-semibold text-primary">Os Meus Anúncios</h3>
            <Button variant="outline" size="sm" onClick={() => navigate('/marketplace')}>
              Ver Todos
            </Button>
          </div>
          
          {loadingAnuncios ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[...Array(3)].map((_, i) => (
                <Card key={i} className="shadow-elegant animate-pulse">
                  <div className="flex p-4 gap-4">
                    <div className="w-20 h-16 bg-muted rounded" />
                    <div className="flex-1 space-y-2">
                      <div className="h-4 bg-muted rounded w-3/4" />
                      <div className="h-3 bg-muted rounded w-1/2" />
                      <div className="h-3 bg-muted rounded w-1/4" />
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          ) : meusAnuncios.length > 0 ? (
            <div className="space-y-4">
              {meusAnuncios.map((anuncio) => (
                <Card key={anuncio.id} className="shadow-elegant">
                  <CardContent className="p-4">
                    <div className="flex gap-4">
                      {/* Imagem */}
                      <div className="w-20 h-16 bg-muted rounded-lg overflow-hidden flex-shrink-0">
                        {anuncio.imagens && anuncio.imagens.length > 0 ? (
                          <img
                            src={getImageUrl(anuncio.imagens[0].url)}
                            alt={anuncio.titulo}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center bg-gradient-subtle">
                            <span className="text-xs text-muted-foreground">Sem imagem</span>
                          </div>
                        )}
                      </div>

                      {/* Conteúdo */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex-1 min-w-0">
                            <h4 className="font-semibold text-primary truncate">{anuncio.titulo}</h4>
                            <div className="flex items-center gap-2 mt-1">
                              <span className="text-lg font-bold text-primary">
                                {anuncio.preco_xs.toFixed(2)} X$
                              </span>
                              {anuncio.categoria && (
                                <Badge variant="secondary" className="text-xs">
                                  {anuncio.categoria.nome}
                                </Badge>
                              )}
                              {anuncio.destaque && (
                                <Badge className="bg-gradient-primary text-xs">Destaque</Badge>
                              )}
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-2 ml-4">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => navigate(`/anuncio/${anuncio.id}`)}
                            >
                              <Eye className="w-3 h-3 mr-1" />
                              Ver
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => toggleDisponivel(anuncio.id, !anuncio.disponivel)}
                            >
                              {anuncio.disponivel ? 'Pausar' : 'Ativar'}
                            </Button>
                          </div>
                        </div>

                        {/* Estatísticas */}
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Eye className="w-3 h-3" />
                            {anuncio.views} views
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {new Date(anuncio.created_at).toLocaleDateString('pt-PT')}
                          </div>
                          <Badge variant={anuncio.disponivel ? "default" : "secondary"} className="text-xs">
                            {anuncio.disponivel ? 'Ativo' : 'Pausado'}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
              
              {meusAnuncios.length === 5 && (
                <Card className="shadow-elegant">
                  <CardContent className="p-4 text-center">
                    <p className="text-muted-foreground mb-2">Ver todos os seus anúncios</p>
                    <Button variant="outline" onClick={() => navigate('/marketplace')}>
                      Ver Marketplace
                    </Button>
                  </CardContent>
                </Card>
              )}
            </div>
          ) : (
            <Card className="shadow-elegant">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 mx-auto mb-4 bg-muted rounded-full flex items-center justify-center">
                  <Plus className="w-8 h-8 text-muted-foreground" />
                </div>
                <h4 className="text-lg font-semibold text-primary mb-2">
                  Ainda não tem anúncios
                </h4>
                <p className="text-muted-foreground mb-4">
                  Crie o seu primeiro anúncio e comece a fazer permutas!
                </p>
                <Button onClick={() => navigate('/criar-anuncio')} className="bg-gradient-primary">
                  <Plus className="w-4 h-4 mr-2" />
                  Criar Primeiro Anúncio
                </Button>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Widget de Mensagens */}
        <div className="mb-8">
          <MensagensWidget />
        </div>

        {/* Informações da Conta */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Perfil Público */}
          <Card className="shadow-elegant">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="w-5 h-5" />
                O Seu Perfil Público
              </CardTitle>
              <CardDescription>
                Como outros utilizadores veem o seu perfil
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Nome:</span>
                <span className="text-sm font-medium">{profile?.nome}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Tipo:</span>
                <span className="text-sm font-medium">
                  {profile?.tipo_utilizador === 'pessoa_singular' ? 'Pessoa Singular' : 'Pessoa Coletiva'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Localidade:</span>
                <span className="text-sm font-medium">{profile?.localidade || 'Não definida'}</span>
              </div>
              <Separator />
              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="flex-1">
                  <Eye className="w-4 h-4 mr-2" />
                  Ver Perfil Público
                </Button>
                <Button variant="outline" size="sm" className="flex-1">
                  <Edit className="w-4 h-4 mr-2" />
                  Editar Perfil
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Código de Indicação */}
          <Card className="shadow-elegant">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5" />
                Programa de Indicação
              </CardTitle>
              <CardDescription>
                Ganhe bónus por cada pessoa que indicar
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-gradient-primary/10 p-4 rounded-lg">
                <p className="text-sm text-muted-foreground mb-2">O seu código de indicação:</p>
                <div className="flex items-center gap-2">
                  <code className="bg-white px-3 py-2 rounded border text-primary font-mono font-bold">
                    {profile?.codigo_indicacao}
                  </code>
                  <Button size="sm" variant="outline">
                    Copiar
                  </Button>
                </div>
              </div>
              <p className="text-xs text-muted-foreground">
                Partilhe este código com amigos e ganhem ambos bónus em euros para descontar em futuras comissões!
              </p>
              <Button variant="outline" size="sm" className="w-full">
                Partilhar Código
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;