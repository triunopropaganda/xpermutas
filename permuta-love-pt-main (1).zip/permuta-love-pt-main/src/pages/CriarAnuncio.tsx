import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { 
  Upload, 
  X, 
  Plus,
  ImageIcon,
  ArrowLeft,
  Save
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { ImageUpload } from '@/components/ImageUpload';

interface Categoria {
  id: string;
  nome: string;
  icone: string;
}

const CriarAnuncio = () => {
  const navigate = useNavigate();
  const { user, profile } = useAuth();
  const { toast } = useToast();
  
  const [categorias, setCategorias] = useState<Categoria[]>([]);
  const [loading, setLoading] = useState(false);
  const [imagens, setImagens] = useState<string[]>([]);
  
  const [formData, setFormData] = useState({
    titulo: '',
    descricao: '',
    categoria_id: '',
    preco_xs: '',
    localizacao: '',
    estado: 'novo',
    aceita_troca: false,
    aceita_euros: false
  });

  useEffect(() => {
    if (!user) {
      navigate('/auth');
      return;
    }
    loadCategorias();
  }, [user, navigate]);

  const loadCategorias = async () => {
    const { data } = await supabase
      .from('categorias')
      .select('*')
      .eq('ativa', true)
      .order('nome');
    
    if (data) setCategorias(data);
  };


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!profile) {
      toast({
        title: "Erro",
        description: "Perfil não encontrado",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);

    try {
      // Criar anúncio
      const { data: anuncio, error: anuncioError } = await supabase
        .from('anuncios')
        .insert({
          ...formData,
          preco_xs: parseFloat(formData.preco_xs),
          utilizador_id: profile.id
        })
        .select()
        .single();

      if (anuncioError) throw anuncioError;

      // Adicionar imagens
      if (imagens.length > 0 && anuncio) {
        const imagensData = imagens.map((url, index) => ({
          anuncio_id: anuncio.id,
          url,
          ordem: index
        }));

        const { error: imagensError } = await supabase
          .from('anuncios_imagens')
          .insert(imagensData);

        if (imagensError) throw imagensError;
      }

      toast({
        title: "Sucesso!",
        description: "Anúncio criado com sucesso"
      });

      navigate('/marketplace');
    } catch (error) {
      console.error('Erro ao criar anúncio:', error);
      toast({
        title: "Erro",
        description: "Erro ao criar anúncio. Tente novamente.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const getImageUrl = (url: string) => {
    // Se for uma URL do storage do Supabase, retornar diretamente
    if (url.includes('supabase') || url.startsWith('http')) {
      return url;
    }
    // Se for um placeholder do Unsplash
    if (url.startsWith('photo-')) {
      return `https://images.unsplash.com/${url}?w=200&h=150&fit=crop`;
    }
    return url;
  };

  return (
    <div className="min-h-screen bg-gradient-subtle py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => navigate(-1)}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-primary">Criar Anúncio</h1>
            <p className="text-muted-foreground">
              Publique o seu produto ou serviço no marketplace
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Formulário principal */}
            <div className="lg:col-span-2 space-y-6">
              {/* Informações básicas */}
              <Card className="shadow-elegant">
                <CardHeader>
                  <CardTitle>Informações Básicas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="titulo">Título do Anúncio *</Label>
                    <Input
                      id="titulo"
                      value={formData.titulo}
                      onChange={(e) => setFormData(prev => ({ ...prev, titulo: e.target.value }))}
                      placeholder="Ex: iPhone 14 Pro Max 256GB"
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="categoria">Categoria *</Label>
                    <Select
                      value={formData.categoria_id}
                      onValueChange={(value) => setFormData(prev => ({ ...prev, categoria_id: value }))}
                      required
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione uma categoria" />
                      </SelectTrigger>
                      <SelectContent>
                        {categorias.map((categoria) => (
                          <SelectItem key={categoria.id} value={categoria.id}>
                            {categoria.nome}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="descricao">Descrição *</Label>
                    <Textarea
                      id="descricao"
                      value={formData.descricao}
                      onChange={(e) => setFormData(prev => ({ ...prev, descricao: e.target.value }))}
                      placeholder="Descreva o seu produto ou serviço em detalhe..."
                      className="min-h-32"
                      required
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Preço e condições */}
              <Card className="shadow-elegant">
                <CardHeader>
                  <CardTitle>Preço e Condições</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="preco">Preço em X$ *</Label>
                      <Input
                        id="preco"
                        type="number"
                        step="0.01"
                        value={formData.preco_xs}
                        onChange={(e) => setFormData(prev => ({ ...prev, preco_xs: e.target.value }))}
                        placeholder="0.00"
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="estado">Estado do Item</Label>
                      <Select
                        value={formData.estado}
                        onValueChange={(value) => setFormData(prev => ({ ...prev, estado: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="novo">Novo</SelectItem>
                          <SelectItem value="usado">Usado</SelectItem>
                          <SelectItem value="recondicionado">Recondicionado</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="localizacao">Localização</Label>
                    <Input
                      id="localizacao"
                      value={formData.localizacao}
                      onChange={(e) => setFormData(prev => ({ ...prev, localizacao: e.target.value }))}
                      placeholder="Ex: Lisboa, Porto, Faro..."
                    />
                  </div>

                  <div className="bg-muted/30 p-4 rounded-lg">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 bg-primary/20 rounded-full flex items-center justify-center">
                        <span className="text-primary text-sm font-bold">X$</span>
                      </div>
                      <div>
                        <p className="text-sm font-medium">Pagamento em X$</p>
                        <p className="text-xs text-muted-foreground">
                          Todas as transações são realizadas exclusivamente em X$
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Imagens */}
              <Card className="shadow-elegant">
                <CardHeader>
                  <CardTitle>Imagens</CardTitle>
                </CardHeader>
                <CardContent>
                  <ImageUpload
                    images={imagens}
                    onImagesChange={setImagens}
                    maxImages={5}
                  />
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Preview */}
              <Card className="shadow-elegant">
                <CardHeader>
                  <CardTitle className="text-lg">Pré-visualização</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="aspect-video bg-muted rounded-lg flex items-center justify-center">
                      {imagens.length > 0 ? (
                        <img
                          src={getImageUrl(imagens[0])}
                          alt="Preview"
                          className="w-full h-full object-cover rounded-lg"
                        />
                      ) : (
                        <ImageIcon className="w-8 h-8 text-muted-foreground" />
                      )}
                    </div>
                    
                    <div>
                      <h3 className="font-semibold text-primary">
                        {formData.titulo || 'Título do anúncio'}
                      </h3>
                      <p className="text-2xl font-bold text-primary">
                        {formData.preco_xs ? `${formData.preco_xs} X$` : '0.00 X$'}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Ações */}
              <Card className="shadow-elegant">
                <CardContent className="pt-6">
                  <div className="space-y-3">
                    <Button
                      type="submit"
                      className="w-full bg-gradient-primary"
                      disabled={loading}
                    >
                      <Save className="w-4 h-4 mr-2" />
                      {loading ? 'Publicando...' : 'Publicar Anúncio'}
                    </Button>
                    
                    <Button
                      type="button"
                      variant="outline"
                      className="w-full"
                      onClick={() => navigate('/marketplace')}
                    >
                      Cancelar
                    </Button>
                  </div>
                  
                  <div className="mt-4 p-4 bg-muted/50 rounded-lg">
                    <p className="text-xs text-muted-foreground">
                      💡 <strong>Dica:</strong> Anúncios com imagens e descrições detalhadas recebem mais visualizações!
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CriarAnuncio;