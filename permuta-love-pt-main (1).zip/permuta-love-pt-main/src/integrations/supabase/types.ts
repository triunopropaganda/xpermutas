export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instanciate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "12.2.12 (cd3cf9e)"
  }
  public: {
    Tables: {
      anuncios: {
        Row: {
          aceita_euros: boolean | null
          aceita_troca: boolean | null
          categoria_id: string | null
          created_at: string
          descricao: string
          destaque: boolean | null
          disponivel: boolean | null
          estado: string | null
          favoritos: number | null
          id: string
          localizacao: string | null
          preco_xs: number
          titulo: string
          updated_at: string
          utilizador_id: string
          views: number | null
        }
        Insert: {
          aceita_euros?: boolean | null
          aceita_troca?: boolean | null
          categoria_id?: string | null
          created_at?: string
          descricao: string
          destaque?: boolean | null
          disponivel?: boolean | null
          estado?: string | null
          favoritos?: number | null
          id?: string
          localizacao?: string | null
          preco_xs?: number
          titulo: string
          updated_at?: string
          utilizador_id: string
          views?: number | null
        }
        Update: {
          aceita_euros?: boolean | null
          aceita_troca?: boolean | null
          categoria_id?: string | null
          created_at?: string
          descricao?: string
          destaque?: boolean | null
          disponivel?: boolean | null
          estado?: string | null
          favoritos?: number | null
          id?: string
          localizacao?: string | null
          preco_xs?: number
          titulo?: string
          updated_at?: string
          utilizador_id?: string
          views?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "anuncios_categoria_id_fkey"
            columns: ["categoria_id"]
            isOneToOne: false
            referencedRelation: "categorias"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_anuncios_utilizador"
            columns: ["utilizador_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      anuncios_imagens: {
        Row: {
          anuncio_id: string
          created_at: string
          id: string
          ordem: number | null
          url: string
        }
        Insert: {
          anuncio_id: string
          created_at?: string
          id?: string
          ordem?: number | null
          url: string
        }
        Update: {
          anuncio_id?: string
          created_at?: string
          id?: string
          ordem?: number | null
          url?: string
        }
        Relationships: [
          {
            foreignKeyName: "anuncios_imagens_anuncio_id_fkey"
            columns: ["anuncio_id"]
            isOneToOne: false
            referencedRelation: "anuncios"
            referencedColumns: ["id"]
          },
        ]
      }
      categorias: {
        Row: {
          ativa: boolean | null
          created_at: string
          descricao: string | null
          icone: string | null
          id: string
          nome: string
          updated_at: string
        }
        Insert: {
          ativa?: boolean | null
          created_at?: string
          descricao?: string | null
          icone?: string | null
          id?: string
          nome: string
          updated_at?: string
        }
        Update: {
          ativa?: boolean | null
          created_at?: string
          descricao?: string | null
          icone?: string | null
          id?: string
          nome?: string
          updated_at?: string
        }
        Relationships: []
      }
      favoritos: {
        Row: {
          anuncio_id: string
          created_at: string
          id: string
          utilizador_id: string
        }
        Insert: {
          anuncio_id: string
          created_at?: string
          id?: string
          utilizador_id: string
        }
        Update: {
          anuncio_id?: string
          created_at?: string
          id?: string
          utilizador_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "favoritos_anuncio_id_fkey"
            columns: ["anuncio_id"]
            isOneToOne: false
            referencedRelation: "anuncios"
            referencedColumns: ["id"]
          },
        ]
      }
      linhas_credito: {
        Row: {
          created_at: string
          data_vencimento: string
          id: string
          status: string | null
          updated_at: string
          utilizador_id: string
          valor_emprestado: number
          valor_pago: number | null
        }
        Insert: {
          created_at?: string
          data_vencimento: string
          id?: string
          status?: string | null
          updated_at?: string
          utilizador_id: string
          valor_emprestado: number
          valor_pago?: number | null
        }
        Update: {
          created_at?: string
          data_vencimento?: string
          id?: string
          status?: string | null
          updated_at?: string
          utilizador_id?: string
          valor_emprestado?: number
          valor_pago?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "linhas_credito_utilizador_id_fkey"
            columns: ["utilizador_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      mensagens: {
        Row: {
          anuncio_id: string
          created_at: string
          destinatario_id: string
          id: string
          lida: boolean | null
          mensagem: string
          remetente_id: string
        }
        Insert: {
          anuncio_id: string
          created_at?: string
          destinatario_id: string
          id?: string
          lida?: boolean | null
          mensagem: string
          remetente_id: string
        }
        Update: {
          anuncio_id?: string
          created_at?: string
          destinatario_id?: string
          id?: string
          lida?: boolean | null
          mensagem?: string
          remetente_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "mensagens_anuncio_id_fkey"
            columns: ["anuncio_id"]
            isOneToOne: false
            referencedRelation: "anuncios"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          ativo: boolean | null
          bonus_euros: number | null
          codigo_indicacao: string
          codigo_postal: string | null
          created_at: string
          descricao: string | null
          distrito: string | null
          email: string
          id: string
          indicado_por: string | null
          localidade: string | null
          logotipo_url: string | null
          morada: string | null
          nif: string | null
          nipc: string | null
          nome: string | null
          nome_empresa: string | null
          saldo_xs: number | null
          telefone: string | null
          tipo_utilizador: string
          updated_at: string
          user_id: string
          verificado: boolean | null
          website: string | null
        }
        Insert: {
          ativo?: boolean | null
          bonus_euros?: number | null
          codigo_indicacao?: string
          codigo_postal?: string | null
          created_at?: string
          descricao?: string | null
          distrito?: string | null
          email: string
          id?: string
          indicado_por?: string | null
          localidade?: string | null
          logotipo_url?: string | null
          morada?: string | null
          nif?: string | null
          nipc?: string | null
          nome?: string | null
          nome_empresa?: string | null
          saldo_xs?: number | null
          telefone?: string | null
          tipo_utilizador?: string
          updated_at?: string
          user_id: string
          verificado?: boolean | null
          website?: string | null
        }
        Update: {
          ativo?: boolean | null
          bonus_euros?: number | null
          codigo_indicacao?: string
          codigo_postal?: string | null
          created_at?: string
          descricao?: string | null
          distrito?: string | null
          email?: string
          id?: string
          indicado_por?: string | null
          localidade?: string | null
          logotipo_url?: string | null
          morada?: string | null
          nif?: string | null
          nipc?: string | null
          nome?: string | null
          nome_empresa?: string | null
          saldo_xs?: number | null
          telefone?: string | null
          tipo_utilizador?: string
          updated_at?: string
          user_id?: string
          verificado?: boolean | null
          website?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "profiles_indicado_por_fkey"
            columns: ["indicado_por"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      transacoes_xs: {
        Row: {
          created_at: string
          de_utilizador_id: string
          descricao: string
          id: string
          para_utilizador_id: string
          referencia_externa: string | null
          tipo: string
          valor: number
        }
        Insert: {
          created_at?: string
          de_utilizador_id: string
          descricao: string
          id?: string
          para_utilizador_id: string
          referencia_externa?: string | null
          tipo: string
          valor: number
        }
        Update: {
          created_at?: string
          de_utilizador_id?: string
          descricao?: string
          id?: string
          para_utilizador_id?: string
          referencia_externa?: string | null
          tipo?: string
          valor?: number
        }
        Relationships: [
          {
            foreignKeyName: "transacoes_xs_de_utilizador_id_fkey"
            columns: ["de_utilizador_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "transacoes_xs_para_utilizador_id_fkey"
            columns: ["para_utilizador_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      incrementar_views_anuncio: {
        Args: { anuncio_uuid: string }
        Returns: undefined
      }
      processar_transacao_xs: {
        Args: {
          p_tipo: string
          p_valor: number
          p_de_utilizador_id: string
          p_para_utilizador_id?: string
          p_anuncio_id?: string
          p_descricao?: string
          p_referencia_externa?: string
        }
        Returns: string
      }
      toggle_anuncio_disponibilidade: {
        Args: {
          anuncio_id: string
          novo_status: boolean
          utilizador_profile_id: string
        }
        Returns: Json
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
