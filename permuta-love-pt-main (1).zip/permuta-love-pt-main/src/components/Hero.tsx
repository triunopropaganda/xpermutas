import { Button } from "@/components/ui/button";
import { ArrowRightIcon, ShieldCheckIcon, UsersIcon, TrendingUpIcon } from "lucide-react";

export default function Hero() {
  return (
    <section className="relative overflow-hidden bg-gradient-hero text-white">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 w-20 h-20 border-2 border-white rounded-full animate-float"></div>
        <div className="absolute top-32 right-20 w-16 h-16 border-2 border-white rounded-full animate-float" style={{ animationDelay: '1s' }}></div>
        <div className="absolute bottom-20 left-1/4 w-12 h-12 border-2 border-white rounded-full animate-float" style={{ animationDelay: '2s' }}></div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="py-20 lg:py-32">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Content */}
            <div className="text-center lg:text-left">
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
                A Revolução das
                <span className="block text-primary">Permutas Multilaterais</span>
                em Portugal
              </h1>
              
              <p className="text-xl lg:text-2xl mb-8 text-white/90 leading-relaxed">
                Transforme os seus produtos e serviços em moeda de troca. 
                Participe numa economia circular que beneficia todos.
              </p>

              {/* Stats */}
              <div className="flex flex-wrap justify-center lg:justify-start gap-6 mb-10">
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">1 X$ = 1€</div>
                  <div className="text-sm text-white/80">Paridade Simples</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">0€</div>
                  <div className="text-sm text-white/80">Custo de Registo</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">10%</div>
                  <div className="text-sm text-white/80">Comissão Justa</div>
                </div>
              </div>

              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <Button 
                  size="lg" 
                  className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-glow animate-glow"
                >
                  Começar Agora
                  <ArrowRightIcon className="ml-2 h-5 w-5" />
                </Button>
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="border-white text-white hover:bg-white hover:text-secondary"
                >
                  Como Funciona
                </Button>
              </div>
            </div>

            {/* Visual Elements */}
            <div className="relative">
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20">
                <h3 className="text-2xl font-bold mb-6 text-center">Exemplo de Permuta</h3>
                
                <div className="space-y-4">
                  {/* Step 1 */}
                  <div className="flex items-center space-x-4 bg-white/10 rounded-lg p-4">
                    <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center font-bold text-white">
                      1
                    </div>
                    <div>
                      <div className="font-semibold">João vende consultoria</div>
                      <div className="text-sm text-white/80">Recebe 500 X$ da Maria</div>
                    </div>
                  </div>

                  {/* Arrow */}
                  <div className="flex justify-center">
                    <ArrowRightIcon className="h-6 w-6 text-primary rotate-90 sm:rotate-0" />
                  </div>

                  {/* Step 2 */}
                  <div className="flex items-center space-x-4 bg-white/10 rounded-lg p-4">
                    <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center font-bold text-white">
                      2
                    </div>
                    <div>
                      <div className="font-semibold">João compra material</div>
                      <div className="text-sm text-white/80">Usa os 500 X$ com o Carlos</div>
                    </div>
                  </div>
                </div>

                <div className="mt-6 text-center">
                  <div className="text-primary font-bold">Economia Circular Ativa!</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Trust Indicators */}
      <div className="border-t border-white/20 bg-white/5">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div className="flex flex-col items-center">
              <ShieldCheckIcon className="h-8 w-8 text-primary mb-3" />
              <h4 className="font-semibold mb-2">100% Seguro</h4>
              <p className="text-sm text-white/80">Transações protegidas e verificadas</p>
            </div>
            <div className="flex flex-col items-center">
              <UsersIcon className="h-8 w-8 text-primary mb-3" />
              <h4 className="font-semibold mb-2">Comunidade Ativa</h4>
              <p className="text-sm text-white/80">Milhares de empresas conectadas</p>
            </div>
            <div className="flex flex-col items-center">
              <TrendingUpIcon className="h-8 w-8 text-primary mb-3" />
              <h4 className="font-semibold mb-2">Crescimento Sustentável</h4>
              <p className="text-sm text-white/80">Economia circular em expansão</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}