import { Button } from "@/components/ui/button";
import { MenuIcon, UserIcon, SearchIcon, LogIn } from "lucide-react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const navigate = useNavigate();
  const { user, profile } = useAuth();

  return (
    <header className="sticky top-0 z-50 w-full bg-white/95 backdrop-blur-sm border-b border-border shadow-elegant">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center space-x-2">
            <img 
              src="/lovable-uploads/6424b562-aa91-4913-853a-7befc94bbb0b.png" 
              alt="XPermutas.pt" 
              className="h-8 w-auto"
            />
          </div>

          {/* Navigation - Desktop */}
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#como-funciona" className="text-secondary hover:text-primary transition-colors font-medium">
              Como Funciona
            </a>
            <a href="#vantagens" className="text-secondary hover:text-primary transition-colors font-medium">
              Vantagens
            </a>
            <button onClick={() => navigate('/marketplace')} className="text-secondary hover:text-primary transition-colors font-medium">
              Marketplace
            </button>
            <a href="#contactos" className="text-secondary hover:text-primary transition-colors font-medium">
              Contactos
            </a>
          </nav>

          {/* Search Bar - Desktop */}
          <div className="hidden lg:flex items-center flex-1 max-w-md mx-8">
            <div className="relative w-full">
              <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <input
                type="text"
                placeholder="Procurar produtos e serviços..."
                className="w-full pl-10 pr-4 py-2 rounded-full border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              />
            </div>
          </div>

          {/* Auth Buttons - Desktop */}
          <div className="hidden md:flex items-center space-x-3">
            {user ? (
              <Button 
                size="sm" 
                className="bg-gradient-primary hover:opacity-90"
                onClick={() => navigate('/dashboard')}
              >
                <UserIcon className="h-4 w-4 mr-2" />
                {profile?.nome || 'Dashboard'}
              </Button>
            ) : (
              <>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => navigate('/auth')}
                >
                  <LogIn className="h-4 w-4 mr-2" />
                  Entrar
                </Button>
                <Button 
                  size="sm" 
                  className="bg-gradient-primary hover:opacity-90"
                  onClick={() => navigate('/auth')}
                >
                  Registar-me
                </Button>
              </>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 rounded-md text-secondary hover:text-primary hover:bg-accent"
          >
            <MenuIcon className="h-6 w-6" />
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden border-t border-border bg-white">
            <div className="px-4 py-4 space-y-4">
              {/* Mobile Search */}
              <div className="relative">
                <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <input
                  type="text"
                  placeholder="Procurar..."
                  className="w-full pl-10 pr-4 py-2 rounded-full border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
              
              {/* Mobile Navigation */}
              <nav className="space-y-3">
                <a href="#como-funciona" className="block text-secondary hover:text-primary font-medium">
                  Como Funciona
                </a>
                <a href="#vantagens" className="block text-secondary hover:text-primary font-medium">
                  Vantagens
                </a>
                <button onClick={() => navigate('/marketplace')} className="block text-secondary hover:text-primary font-medium">
                  Marketplace
                </button>
                <a href="#contactos" className="block text-secondary hover:text-primary font-medium">
                  Contactos
                </a>
              </nav>
              
              {/* Mobile Auth Buttons */}
              <div className="space-y-2 pt-4 border-t border-border">
                {user ? (
                  <Button 
                    className="w-full bg-gradient-primary hover:opacity-90"
                    onClick={() => navigate('/dashboard')}
                  >
                    <UserIcon className="h-4 w-4 mr-2" />
                    {profile?.nome || 'Dashboard'}
                  </Button>
                ) : (
                  <>
                    <Button 
                      variant="outline" 
                      className="w-full"
                      onClick={() => navigate('/auth')}
                    >
                      <LogIn className="h-4 w-4 mr-2" />
                      Entrar
                    </Button>
                    <Button 
                      className="w-full bg-gradient-primary hover:opacity-90"
                      onClick={() => navigate('/auth')}
                    >
                      Registar-me
                    </Button>
                  </>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}