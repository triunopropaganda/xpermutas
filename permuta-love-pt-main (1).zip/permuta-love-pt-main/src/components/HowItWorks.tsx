import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  UserPlusIcon, 
  StoreIcon, 
  CreditCardIcon, 
  RefreshCwIcon,
  ArrowRightIcon,
  CoinsIcon
} from "lucide-react";

export default function HowItWorks() {
  const steps = [
    {
      icon: UserPlusIcon,
      title: "Registe-se Gratuitamente",
      description: "Crie a sua conta como pessoa singular ou coletiva. O registo é 100% gratuito e sem custos ocultos.",
      details: "Apenas precisa de alguns dados básicos para começar"
    },
    {
      icon: StoreIcon,
      title: "Publique as Suas Ofertas",
      description: "Anuncie os seus produtos e serviços na plataforma. Defina preços em X$ (moeda da plataforma).",
      details: "Sem custos de publicação ou taxas mensais"
    },
    {
      icon: CoinsIcon,
      title: "Venda e Ganhe X$",
      description: "Quando alguém compra de si, recebe o valor integral em X$ (moeda virtual equivalente a euros).",
      details: "1 X$ = 1 Euro - Paridade simples e transparente"
    },
    {
      icon: CreditCardIcon,
      title: "Compre com X$",
      description: "Use os seus X$ para comprar qualquer produto ou serviço disponível na plataforma.",
      details: "Apenas paga 10% de comissão em euros ao comprar"
    },
    {
      icon: RefreshCwIcon,
      title: "Economia Circular",
      description: "Participe numa rede de permutas multilaterais onde todos beneficiam do intercâmbio contínuo.",
      details: "Não precisa de comprar diretamente a quem lhe vendeu"
    }
  ];

  return (
    <section id="como-funciona" className="py-20 bg-gradient-to-br from-background via-accent/20 to-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-secondary mb-6">
            Como Funciona a XPermutas.pt?
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Descubra como pode participar na maior rede de permutas multilaterais de Portugal
          </p>
        </div>

        {/* Steps */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {steps.map((step, index) => (
            <Card key={index} className="relative group hover:shadow-elegant transition-all duration-300 border-l-4 border-l-primary">
              <CardContent className="p-6">
                {/* Step Number */}
                <div className="absolute -top-4 -left-4 w-8 h-8 bg-gradient-primary rounded-full flex items-center justify-center text-white font-bold text-sm shadow-md">
                  {index + 1}
                </div>

                {/* Icon */}
                <div className="mb-4">
                  <step.icon className="h-12 w-12 text-primary group-hover:scale-110 transition-transform duration-300" />
                </div>

                {/* Content */}
                <h3 className="text-xl font-bold text-secondary mb-3">
                  {step.title}
                </h3>
                <p className="text-muted-foreground mb-3">
                  {step.description}
                </p>
                <p className="text-sm text-primary font-medium">
                  {step.details}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Example Flow */}
        <div className="bg-white rounded-2xl p-8 shadow-elegant border">
          <h3 className="text-2xl font-bold text-secondary mb-8 text-center">
            Exemplo Prático de Permuta Multilateral
          </h3>

          <div className="grid md:grid-cols-3 gap-6">
            {/* Participant 1 */}
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-white font-bold text-lg">A</span>
              </div>
              <h4 className="font-bold text-secondary mb-2">Empresa A (João)</h4>
              <p className="text-sm text-muted-foreground mb-3">Consultoria de Marketing</p>
              <div className="bg-accent/50 rounded-lg p-3">
                <p className="text-sm">Vende serviço por <span className="font-bold text-primary">500 X$</span></p>
              </div>
            </div>

            {/* Arrow */}
            <div className="flex items-center justify-center">
              <ArrowRightIcon className="h-8 w-8 text-primary rotate-90 md:rotate-0" />
            </div>

            {/* Participant 2 */}
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-secondary rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-white font-bold text-lg">B</span>
              </div>
              <h4 className="font-bold text-secondary mb-2">Empresa B (Maria)</h4>
              <p className="text-sm text-muted-foreground mb-3">Loja de Roupa</p>
              <div className="bg-secondary/10 rounded-lg p-3">
                <p className="text-sm">Compra serviço + paga <span className="font-bold text-destructive">50€ comissão</span></p>
              </div>
            </div>
          </div>

          <div className="my-8 flex justify-center">
            <ArrowRightIcon className="h-8 w-8 text-primary rotate-90" />
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {/* Participant 3 */}
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-primary to-secondary rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-white font-bold text-lg">C</span>
              </div>
              <h4 className="font-bold text-secondary mb-2">Empresa C (Carlos)</h4>
              <p className="text-sm text-muted-foreground mb-3">Material de Escritório</p>
              <div className="bg-accent/50 rounded-lg p-3">
                <p className="text-sm">Recebe <span className="font-bold text-primary">500 X$</span> do João</p>
              </div>
            </div>

            {/* Arrow */}
            <div className="flex items-center justify-center">
              <ArrowRightIcon className="h-8 w-8 text-primary rotate-180 md:rotate-180" />
            </div>

            {/* Back to Participant 1 */}
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-white font-bold text-lg">A</span>
              </div>
              <h4 className="font-bold text-secondary mb-2">Empresa A (João)</h4>
              <p className="text-sm text-muted-foreground mb-3">Consultoria de Marketing</p>
              <div className="bg-accent/50 rounded-lg p-3">
                <p className="text-sm">Usa os <span className="font-bold text-primary">500 X$</span> para comprar</p>
              </div>
            </div>
          </div>

          <div className="mt-8 text-center">
            <div className="inline-flex items-center space-x-2 bg-primary/10 text-primary px-4 py-2 rounded-full font-medium">
              <RefreshCwIcon className="h-5 w-5" />
              <span>Ciclo de Permutas Ativo!</span>
            </div>
          </div>
        </div>

        {/* CTA */}
        <div className="text-center mt-12">
          <Button size="lg" className="bg-gradient-primary hover:opacity-90 shadow-glow">
            Começar a Permutar Agora
            <ArrowRightIcon className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>
    </section>
  );
}