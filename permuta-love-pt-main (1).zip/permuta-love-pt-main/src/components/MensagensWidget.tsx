import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MessageSquare, User, Eye } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

interface Conversa {
  anuncio_id: string;
  anuncio_titulo: string;
  outro_utilizador_nome: string;
  ultimo_remetente_id: string;
  ultima_mensagem: string;
  ultima_data: string;
  mensagens_nao_lidas: number;
  total_mensagens: number;
}

export const MensagensWidget = () => {
  const [conversas, setConversas] = useState<Conversa[]>([]);
  const [loading, setLoading] = useState(true);
  const { profile } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (profile?.id) {
      loadConversas();
    }
  }, [profile]);

  const loadConversas = async () => {
    if (!profile?.id) return;

    try {
      const { data, error } = await supabase
        .from('mensagens')
        .select(`
          anuncio_id,
          remetente_id,
          destinatario_id,
          mensagem,
          created_at,
          lida,
          anuncios!inner(titulo)
        `)
        .or(`remetente_id.eq.${profile.id},destinatario_id.eq.${profile.id}`)
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Buscar nomes dos perfis
      const profileIds = [...new Set([...data.map(m => m.remetente_id), ...data.map(m => m.destinatario_id)])];
      const { data: profiles } = await supabase
        .from('profiles')
        .select('id, nome')
        .in('id', profileIds);

      const profileMap = new Map(profiles?.map(p => [p.id, p.nome]) || []);

      // Agrupar mensagens por anúncio e outro utilizador
      const conversasMap = new Map<string, Conversa>();

      data?.forEach((mensagem: any) => {
        const outroUtilizadorId = mensagem.remetente_id === profile.id 
          ? mensagem.destinatario_id 
          : mensagem.remetente_id;
        
        const outroUtilizadorNome = profileMap.get(outroUtilizadorId) || 'Utilizador';

        const chaveConversa = `${mensagem.anuncio_id}-${outroUtilizadorId}`;

        if (!conversasMap.has(chaveConversa)) {
          conversasMap.set(chaveConversa, {
            anuncio_id: mensagem.anuncio_id,
            anuncio_titulo: mensagem.anuncios.titulo,
            outro_utilizador_nome: outroUtilizadorNome,
            ultimo_remetente_id: mensagem.remetente_id,
            ultima_mensagem: mensagem.mensagem,
            ultima_data: mensagem.created_at,
            mensagens_nao_lidas: 0,
            total_mensagens: 0
          });
        }

        const conversa = conversasMap.get(chaveConversa)!;
        conversa.total_mensagens++;

        // Contar mensagens não lidas (onde sou o destinatário)
        if (mensagem.destinatario_id === profile.id && !mensagem.lida) {
          conversa.mensagens_nao_lidas++;
        }

        // Atualizar com a mensagem mais recente
        if (new Date(mensagem.created_at) > new Date(conversa.ultima_data)) {
          conversa.ultimo_remetente_id = mensagem.remetente_id;
          conversa.ultima_mensagem = mensagem.mensagem;
          conversa.ultima_data = mensagem.created_at;
        }
      });

      setConversas(Array.from(conversasMap.values()));
    } catch (error) {
      console.error('Erro ao carregar conversas:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleVerConversa = (anuncioId: string) => {
    navigate(`/mensagens?anuncio=${anuncioId}`);
  };

  const totalNaoLidas = conversas.reduce((acc, conv) => acc + conv.mensagens_nao_lidas, 0);

  if (loading) {
    return (
      <Card className="shadow-elegant">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5" />
            Mensagens
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">A carregar mensagens...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-elegant">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5" />
            Mensagens
            {totalNaoLidas > 0 && (
              <Badge variant="destructive" className="text-xs">
                {totalNaoLidas}
              </Badge>
            )}
          </div>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => navigate('/mensagens')}
          >
            Ver Todas
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {conversas.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4">
            Ainda não tem mensagens
          </p>
        ) : (
          <>
            {conversas.slice(0, 3).map((conversa, index) => (
              <div 
                key={`${conversa.anuncio_id}-${index}`}
                className="flex items-start gap-3 p-3 border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors"
                onClick={() => handleVerConversa(conversa.anuncio_id)}
              >
                <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                  <User className="w-4 h-4 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-sm font-medium truncate">
                      {conversa.outro_utilizador_nome}
                    </p>
                    {conversa.mensagens_nao_lidas > 0 && (
                      <Badge variant="destructive" className="text-xs ml-2">
                        {conversa.mensagens_nao_lidas}
                      </Badge>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground mb-1 truncate">
                    {conversa.anuncio_titulo}
                  </p>
                  <p className="text-xs text-muted-foreground truncate">
                    {conversa.ultimo_remetente_id === profile?.id ? 'Você: ' : ''}
                    {conversa.ultima_mensagem}
                  </p>
                </div>
                <Button size="sm" variant="ghost" className="p-1">
                  <Eye className="w-4 h-4" />
                </Button>
              </div>
            ))}
            {conversas.length > 3 && (
              <Button 
                variant="outline" 
                size="sm" 
                className="w-full"
                onClick={() => navigate('/mensagens')}
              >
                Ver mais {conversas.length - 3} conversas
              </Button>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
};