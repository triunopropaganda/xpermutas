import { Button } from "@/components/ui/button";
import { 
  FacebookIcon, 
  LinkedinIcon, 
  InstagramIcon, 
  MailIcon, 
  PhoneIcon, 
  MapPinIcon,
  ArrowRightIcon
} from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-secondary text-white">
      {/* Main Footer */}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="lg:col-span-1">
            <img 
              src="/lovable-uploads/6424b562-aa91-4913-853a-7befc94bbb0b.png" 
              alt="XPermutas.pt" 
              className="h-8 w-auto mb-4 brightness-0 invert"
            />
            <p className="text-white/80 mb-6 leading-relaxed">
              A maior plataforma de permutas multilaterais de Portugal. 
              Transformamos produtos e serviços em oportunidades de negócio.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-primary transition-colors">
                <FacebookIcon className="h-5 w-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-primary transition-colors">
                <LinkedinIcon className="h-5 w-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-primary transition-colors">
                <InstagramIcon className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-bold mb-6">Links Rápidos</h4>
            <ul className="space-y-3">
              <li><a href="#como-funciona" className="text-white/80 hover:text-primary transition-colors">Como Funciona</a></li>
              <li><a href="#vantagens" className="text-white/80 hover:text-primary transition-colors">Vantagens</a></li>
              <li><a href="#marketplace" className="text-white/80 hover:text-primary transition-colors">Marketplace</a></li>
              <li><a href="/registo" className="text-white/80 hover:text-primary transition-colors">Criar Conta</a></li>
              <li><a href="/login" className="text-white/80 hover:text-primary transition-colors">Entrar</a></li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="text-lg font-bold mb-6">Legal</h4>
            <ul className="space-y-3">
              <li><a href="/termos" className="text-white/80 hover:text-primary transition-colors">Termos de Utilização</a></li>
              <li><a href="/privacidade" className="text-white/80 hover:text-primary transition-colors">Política de Privacidade</a></li>
              <li><a href="/cookies" className="text-white/80 hover:text-primary transition-colors">Política de Cookies</a></li>
              <li><a href="/faq" className="text-white/80 hover:text-primary transition-colors">FAQ</a></li>
              <li><a href="/suporte" className="text-white/80 hover:text-primary transition-colors">Suporte</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-lg font-bold mb-6">Contactos</h4>
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <MailIcon className="h-5 w-5 text-primary" />
                <span className="text-white/80">info@xpermutas.pt</span>
              </div>
              <div className="flex items-center space-x-3">
                <PhoneIcon className="h-5 w-5 text-primary" />
                <span className="text-white/80">+351 000 000 000</span>
              </div>
              <div className="flex items-center space-x-3">
                <MapPinIcon className="h-5 w-5 text-primary" />
                <span className="text-white/80">Lisboa, Portugal</span>
              </div>
            </div>

            <div className="mt-6">
              <h5 className="font-semibold mb-3">Newsletter</h5>
              <div className="flex space-x-2">
                <input
                  type="email"
                  placeholder="O seu e-mail"
                  className="flex-1 px-3 py-2 bg-white/10 border border-white/20 rounded-md text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-primary"
                />
                <Button size="sm" className="bg-primary hover:bg-primary/90">
                  <ArrowRightIcon className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="text-white/60 text-sm">
              © 2024 XPermutas.pt. Todos os direitos reservados.
            </div>
            <div className="flex items-center space-x-6 text-sm text-white/60">
              <span>Desenvolvido com ❤️ em Portugal</span>
              <div className="flex items-center space-x-2">
                <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                <span>Sistema Online</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}