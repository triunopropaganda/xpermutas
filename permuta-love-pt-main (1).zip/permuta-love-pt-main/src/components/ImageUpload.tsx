import React, { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { X, Upload, ImageIcon } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';

interface ImageUploadProps {
  images: string[];
  onImagesChange: (images: string[]) => void;
  maxImages?: number;
  anuncioId?: string;
}

export const ImageUpload: React.FC<ImageUploadProps> = ({
  images,
  onImagesChange,
  maxImages = 5,
  anuncioId
}) => {
  const [uploading, setUploading] = useState(false);
  const { toast } = useToast();

  const uploadImage = async (file: File): Promise<string | null> => {
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${anuncioId || Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`;
      const filePath = `${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('anuncios')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data } = supabase.storage
        .from('anuncios')
        .getPublicUrl(filePath);

      return data.publicUrl;
    } catch (error) {
      console.error('Erro no upload:', error);
      return null;
    }
  };

  const handleFileSelect = useCallback(async (event: React.ChangeEvent<HTMLInputElement>) => {
    console.log('handleFileSelect chamado', event.target.files);
    const files = event.target.files;
    if (!files || files.length === 0) {
      console.log('Nenhum arquivo selecionado');
      return;
    }

    console.log('Arquivos selecionados:', files.length);

    if (images.length + files.length > maxImages) {
      toast({
        title: "Limite de imagens",
        description: `Máximo de ${maxImages} imagens permitidas`,
        variant: "destructive"
      });
      return;
    }

    setUploading(true);
    const newImages: string[] = [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      console.log('Processando arquivo:', file.name, file.type, file.size);
      
      // Validar tipo de arquivo
      if (!file.type.startsWith('image/')) {
        toast({
          title: "Arquivo inválido",
          description: "Apenas imagens são permitidas",
          variant: "destructive"
        });
        continue;
      }

      // Validar tamanho (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "Arquivo muito grande",
          description: "Máximo de 5MB por imagem",
          variant: "destructive"
        });
        continue;
      }

      console.log('Iniciando upload do arquivo:', file.name);
      const url = await uploadImage(file);
      if (url) {
        console.log('Upload bem-sucedido:', url);
        newImages.push(url);
      } else {
        console.log('Falha no upload do arquivo:', file.name);
      }
    }

    console.log('Novas imagens:', newImages);
    if (newImages.length > 0) {
      onImagesChange([...images, ...newImages]);
      toast({
        title: "Sucesso",
        description: `${newImages.length} imagem(ns) carregada(s)`
      });
    }

    setUploading(false);
    event.target.value = '';
  }, [images, onImagesChange, maxImages, anuncioId, toast]);

  const removeImage = useCallback(async (index: number) => {
    const imageUrl = images[index];
    
    // Só tentar remover do storage se for uma URL do Supabase (nova imagem)
    if (imageUrl.includes('supabase') && imageUrl.includes('/storage/v1/object/public/anuncios/')) {
      try {
        const urlParts = imageUrl.split('/');
        const fileName = urlParts[urlParts.length - 1];
        
        // Remover do storage
        const { error } = await supabase.storage
          .from('anuncios')
          .remove([fileName]);
          
        if (error) {
          console.error('Erro ao remover do storage:', error);
        }
      } catch (error) {
        console.error('Erro ao remover do storage:', error);
      }
    }

    // Remover da lista
    const newImages = images.filter((_, i) => i !== index);
    onImagesChange(newImages);
    
    toast({
      title: "Imagem removida",
      description: "A imagem foi removida com sucesso"
    });
  }, [images, onImagesChange, toast]);

  const moveImage = useCallback((fromIndex: number, toIndex: number) => {
    const newImages = [...images];
    const [movedImage] = newImages.splice(fromIndex, 1);
    newImages.splice(toIndex, 0, movedImage);
    onImagesChange(newImages);
  }, [images, onImagesChange]);

  return (
    <div className="space-y-4">
      {/* Upload Button */}
      <div className="flex items-center gap-4">
        <input
          id="image-upload"
          type="file"
          multiple
          accept="image/*"
          onChange={handleFileSelect}
          className="hidden"
          disabled={uploading || images.length >= maxImages}
        />
        <Button
          type="button"
          variant="outline"
          disabled={uploading || images.length >= maxImages}
          onClick={() => {
            console.log('Botão clicado');
            document.getElementById('image-upload')?.click();
          }}
        >
          <Upload className="w-4 h-4 mr-2" />
          {uploading ? 'A carregar...' : 'Adicionar Imagens'}
        </Button>
        <span className="text-sm text-muted-foreground">
          {images.length}/{maxImages} imagens
        </span>
      </div>

      {/* Image Preview Grid */}
      {images.length > 0 && (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {images.map((image, index) => (
            <Card key={index} className="relative group">
              <CardContent className="p-2">
                <div className="relative aspect-square">
                  <img
                    src={image}
                    alt={`Imagem ${index + 1}`}
                    className="w-full h-full object-cover rounded"
                  />
                  
                  {/* Remove Button */}
                  <Button
                    size="sm"
                    variant="destructive"
                    className="absolute top-1 right-1 w-6 h-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={() => removeImage(index)}
                  >
                    <X className="w-3 h-3" />
                  </Button>

                  {/* Primary Badge */}
                  {index === 0 && (
                    <div className="absolute bottom-1 left-1 bg-primary text-primary-foreground text-xs px-2 py-1 rounded">
                      Principal
                    </div>
                  )}

                  {/* Order Controls */}
                  <div className="absolute bottom-1 right-1 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    {index > 0 && (
                      <Button
                        size="sm"
                        variant="secondary"
                        className="w-6 h-6 p-0 text-xs"
                        onClick={() => moveImage(index, index - 1)}
                      >
                        ←
                      </Button>
                    )}
                    {index < images.length - 1 && (
                      <Button
                        size="sm"
                        variant="secondary"
                        className="w-6 h-6 p-0 text-xs"
                        onClick={() => moveImage(index, index + 1)}
                      >
                        →
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Empty State */}
      {images.length === 0 && (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-8">
            <ImageIcon className="w-12 h-12 text-muted-foreground mb-4" />
            <p className="text-muted-foreground text-center">
              Nenhuma imagem adicionada ainda
            </p>
            <p className="text-sm text-muted-foreground text-center mt-1">
              Clique em "Adicionar Imagens" para começar
            </p>
          </CardContent>
        </Card>
      )}

      <div className="text-xs text-muted-foreground">
        <p>• Máximo {maxImages} imagens</p>
        <p>• Formatos aceites: JPG, PNG, GIF</p>
        <p>• Tamanho máximo: 5MB por imagem</p>
        <p>• A primeira imagem será a principal</p>
      </div>
    </div>
  );
};