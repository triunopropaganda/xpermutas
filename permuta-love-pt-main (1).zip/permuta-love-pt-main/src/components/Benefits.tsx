import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  ZapIcon, 
  ShieldIcon, 
  TrendingUpIcon, 
  UsersIcon, 
  CreditCardIcon, 
  GiftIcon,
  CheckCircleIcon,
  ArrowRightIcon
} from "lucide-react";

export default function Benefits() {
  const benefits = [
    {
      icon: ZapIcon,
      title: "Registo 100% Gratuito",
      description: "Sem custos de inscrição, taxas mensais ou anuais. Comece a permutar imediatamente.",
      highlight: "0€ de custos fixos"
    },
    {
      icon: CreditCardIcon,
      title: "Comissão Justa",
      description: "Apenas 10% de comissão em euros para quem compra. O vendedor recebe sempre o valor integral.",
      highlight: "Transparência total"
    },
    {
      icon: ShieldIcon,
      title: "Sistema de Vouchers",
      description: "Pagamentos seguros com códigos únicos que garantem a entrega antes da transferência.",
      highlight: "Proteção garantida"
    },
    {
      icon: TrendingUpIcon,
      title: "Linha de Crédito em X$",
      description: "Solicite um adiantamento para começar a comprar e quite com as suas vendas futuras.",
      highlight: "Liquidez imediata"
    },
    {
      icon: GiftIcon,
      title: "Programa de Indicação",
      description: "Ganhe bónus em euros para descontar em comissões futuras ao indicar novos utilizadores.",
      highlight: "Benefícios mútuos"
    },
    {
      icon: UsersIcon,
      title: "Rede Multilateral",
      description: "Não precisa de comprar diretamente a quem lhe vendeu. Economia circular verdadeira.",
      highlight: "Flexibilidade máxima"
    }
  ];

  const features = [
    "Paridade simples: 1 X$ = 1 Euro",
    "Sem necessidade de moeda física",
    "Transações instantâneas",
    "Marketplace português",
    "Suporte a pessoas singulares e coletivas",
    "Aplicação móvel (PWA)",
    "Resolução de conflitos mediada",
    "Plano Premium pagável em X$"
  ];

  return (
    <section id="vantagens" className="py-20 bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-secondary mb-6">
            Porquê Escolher a XPermutas.pt?
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Descubra todas as vantagens de participar na maior rede de permutas multilaterais de Portugal
          </p>
        </div>

        {/* Benefits Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {benefits.map((benefit, index) => (
            <Card key={index} className="group hover:shadow-elegant transition-all duration-300 hover:-translate-y-1">
              <CardContent className="p-6">
                {/* Icon */}
                <div className="mb-4">
                  <div className="w-14 h-14 bg-gradient-primary rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                    <benefit.icon className="h-7 w-7 text-white" />
                  </div>
                </div>

                {/* Content */}
                <h3 className="text-xl font-bold text-secondary mb-3">
                  {benefit.title}
                </h3>
                <p className="text-muted-foreground mb-4">
                  {benefit.description}
                </p>
                <div className="inline-flex items-center space-x-2 bg-primary/10 text-primary px-3 py-1 rounded-full text-sm font-medium">
                  <CheckCircleIcon className="h-4 w-4" />
                  <span>{benefit.highlight}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Two Column Layout */}
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Features List */}
          <div>
            <h3 className="text-3xl font-bold text-secondary mb-6">
              Características Únicas
            </h3>
            <p className="text-lg text-muted-foreground mb-8">
              A XPermutas.pt foi desenvolvida especificamente para o mercado português, 
              com funcionalidades pensadas para facilitar o seu dia-a-dia empresarial.
            </p>

            <div className="grid sm:grid-cols-2 gap-4">
              {features.map((feature, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <CheckCircleIcon className="h-5 w-5 text-primary flex-shrink-0" />
                  <span className="text-muted-foreground">{feature}</span>
                </div>
              ))}
            </div>

            <div className="mt-8">
              <Button size="lg" className="bg-gradient-primary hover:opacity-90">
                Ver Todas as Funcionalidades
                <ArrowRightIcon className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </div>

          {/* Visual Comparison */}
          <div className="bg-white rounded-2xl p-8 shadow-elegant border">
            <h4 className="text-2xl font-bold text-secondary mb-6 text-center">
              Modelo Tradicional vs XPermutas.pt
            </h4>

            <div className="space-y-6">
              {/* Traditional */}
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <h5 className="font-bold text-red-800 mb-3">❌ Método Tradicional</h5>
                <ul className="space-y-2 text-sm text-red-700">
                  <li>• Necessita de dinheiro físico</li>
                  <li>• Troca limitada (A ↔ B)</li>
                  <li>• Problemas de liquidez</li>
                  <li>• Custos bancários elevados</li>
                </ul>
              </div>

              {/* XPermutas */}
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <h5 className="font-bold text-green-800 mb-3">✅ XPermutas.pt</h5>
                <ul className="space-y-2 text-sm text-green-700">
                  <li>• Moeda virtual X$ (1 X$ = 1€)</li>
                  <li>• Rede multilateral (A → B → C → A)</li>
                  <li>• Liquidez através da rede</li>
                  <li>• Comissão apenas em compras (10%)</li>
                </ul>
              </div>
            </div>

            <div className="mt-6 text-center">
              <div className="inline-flex items-center space-x-2 bg-primary/10 text-primary px-4 py-2 rounded-full font-bold">
                <TrendingUpIcon className="h-5 w-5" />
                <span>Evolução Natural do Comércio</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}