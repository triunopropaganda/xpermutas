-- Criar tabela de categorias
CREATE TABLE public.categorias (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  nome TEXT NOT NULL,
  descricao TEXT,
  icone TEXT,
  ativa BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Criar tabela de anúncios
CREATE TABLE public.anuncios (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  utilizador_id UUID NOT NULL,
  categoria_id UUID REFERENCES public.categorias(id),
  titulo TEXT NOT NULL,
  descricao TEXT NOT NULL,
  preco_xs NUMERIC NOT NULL DEFAULT 0,
  aceita_troca BOOLEAN DEFAULT true,
  aceita_euros BOOLEAN DEFAULT false,
  localizacao TEXT,
  estado TEXT DEFAULT 'novo' CHECK (estado IN ('novo', 'usado', 'recondicionado')),
  disponivel BOOLEAN DEFAULT true,
  destaque BOOLEAN DEFAULT false,
  views INTEGER DEFAULT 0,
  favoritos INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Criar tabela de imagens dos anúncios
CREATE TABLE public.anuncios_imagens (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  anuncio_id UUID NOT NULL REFERENCES public.anuncios(id) ON DELETE CASCADE,
  url TEXT NOT NULL,
  ordem INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Criar tabela de favoritos
CREATE TABLE public.favoritos (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  utilizador_id UUID NOT NULL,
  anuncio_id UUID NOT NULL REFERENCES public.anuncios(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(utilizador_id, anuncio_id)
);

-- Criar tabela de mensagens entre utilizadores
CREATE TABLE public.mensagens (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  anuncio_id UUID NOT NULL REFERENCES public.anuncios(id) ON DELETE CASCADE,
  remetente_id UUID NOT NULL,
  destinatario_id UUID NOT NULL,
  mensagem TEXT NOT NULL,
  lida BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Ativar RLS
ALTER TABLE public.categorias ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.anuncios ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.anuncios_imagens ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.favoritos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mensagens ENABLE ROW LEVEL SECURITY;

-- Políticas para categorias (públicas)
CREATE POLICY "Categorias são visíveis para todos" 
ON public.categorias 
FOR SELECT 
USING (ativa = true);

-- Políticas para anúncios
CREATE POLICY "Anúncios são visíveis para todos" 
ON public.anuncios 
FOR SELECT 
USING (disponivel = true);

CREATE POLICY "Utilizadores podem criar anúncios" 
ON public.anuncios 
FOR INSERT 
WITH CHECK (utilizador_id IN (SELECT id FROM profiles WHERE user_id = auth.uid()));

CREATE POLICY "Utilizadores podem editar os próprios anúncios" 
ON public.anuncios 
FOR UPDATE 
USING (utilizador_id IN (SELECT id FROM profiles WHERE user_id = auth.uid()));

CREATE POLICY "Utilizadores podem eliminar os próprios anúncios" 
ON public.anuncios 
FOR DELETE 
USING (utilizador_id IN (SELECT id FROM profiles WHERE user_id = auth.uid()));

-- Políticas para imagens
CREATE POLICY "Imagens são visíveis para todos" 
ON public.anuncios_imagens 
FOR SELECT 
USING (true);

CREATE POLICY "Utilizadores podem adicionar imagens aos próprios anúncios" 
ON public.anuncios_imagens 
FOR INSERT 
WITH CHECK (anuncio_id IN (SELECT id FROM anuncios WHERE utilizador_id IN (SELECT id FROM profiles WHERE user_id = auth.uid())));

CREATE POLICY "Utilizadores podem eliminar imagens dos próprios anúncios" 
ON public.anuncios_imagens 
FOR DELETE 
USING (anuncio_id IN (SELECT id FROM anuncios WHERE utilizador_id IN (SELECT id FROM profiles WHERE user_id = auth.uid())));

-- Políticas para favoritos
CREATE POLICY "Utilizadores podem ver os próprios favoritos" 
ON public.favoritos 
FOR SELECT 
USING (utilizador_id IN (SELECT id FROM profiles WHERE user_id = auth.uid()));

CREATE POLICY "Utilizadores podem adicionar favoritos" 
ON public.favoritos 
FOR INSERT 
WITH CHECK (utilizador_id IN (SELECT id FROM profiles WHERE user_id = auth.uid()));

CREATE POLICY "Utilizadores podem remover favoritos" 
ON public.favoritos 
FOR DELETE 
USING (utilizador_id IN (SELECT id FROM profiles WHERE user_id = auth.uid()));

-- Políticas para mensagens
CREATE POLICY "Utilizadores podem ver mensagens onde participam" 
ON public.mensagens 
FOR SELECT 
USING (
  remetente_id IN (SELECT id FROM profiles WHERE user_id = auth.uid()) OR 
  destinatario_id IN (SELECT id FROM profiles WHERE user_id = auth.uid())
);

CREATE POLICY "Utilizadores podem enviar mensagens" 
ON public.mensagens 
FOR INSERT 
WITH CHECK (remetente_id IN (SELECT id FROM profiles WHERE user_id = auth.uid()));

CREATE POLICY "Utilizadores podem marcar mensagens como lidas" 
ON public.mensagens 
FOR UPDATE 
USING (destinatario_id IN (SELECT id FROM profiles WHERE user_id = auth.uid()));

-- Triggers para updated_at
CREATE TRIGGER update_categorias_updated_at
BEFORE UPDATE ON public.categorias
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_anuncios_updated_at
BEFORE UPDATE ON public.anuncios
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Inserir categorias iniciais
INSERT INTO public.categorias (nome, descricao, icone) VALUES
('Electrónicos', 'Computadores, telemóveis, electrodomésticos', 'Smartphone'),
('Moda', 'Roupa, calçado, acessórios', 'Shirt'),
('Casa e Jardim', 'Móveis, decoração, ferramentas', 'Home'),
('Desporto', 'Equipamento desportivo, bicicletas', 'Bike'),
('Automóveis', 'Carros, motos, peças', 'Car'),
('Livros e Mídia', 'Livros, filmes, música', 'Book'),
('Hobbies', 'Coleções, instrumentos musicais', 'Music'),
('Serviços', 'Reparações, limpezas, consultoria', 'Wrench');

-- Função para incrementar views
CREATE OR REPLACE FUNCTION public.incrementar_views_anuncio(anuncio_uuid UUID)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE anuncios SET views = views + 1 WHERE id = anuncio_uuid;
END;
$$;