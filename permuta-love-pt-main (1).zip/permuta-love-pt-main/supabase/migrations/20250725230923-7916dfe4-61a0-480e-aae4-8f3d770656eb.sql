-- Criar bucket para imagens de anúncios
INSERT INTO storage.buckets (id, name, public) VALUES ('anuncios', 'anuncios', true);

-- Criar políticas para o bucket de anúncios
CREATE POLICY "Imagens de anúncios são visíveis para todos" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'anuncios');

CREATE POLICY "Utilizadores autenticados podem fazer upload de imagens" 
ON storage.objects 
FOR INSERT 
WITH CHECK (
  bucket_id = 'anuncios' 
  AND auth.uid() IS NOT NULL
);

CREATE POLICY "Utilizadores podem atualizar as próprias imagens" 
ON storage.objects 
FOR UPDATE 
USING (
  bucket_id = 'anuncios' 
  AND auth.uid() IS NOT NULL
);

CREATE POLICY "Utilizadores podem eliminar as próprias imagens" 
ON storage.objects 
FOR DELETE 
USING (
  bucket_id = 'anuncios' 
  AND auth.uid() IS NOT NULL
);