-- Criar tabela de perfis de utilizadores
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE NOT NULL,
  nome TEXT,
  email TEXT NOT NULL,
  telefone TEXT,
  tipo_utilizador TEXT CHECK (tipo_utilizador IN ('pessoa_singular', 'pessoa_coletiva')) NOT NULL DEFAULT 'pessoa_singular',
  
  -- Campos para pessoa singular
  nif TEXT,
  
  -- Campos para pessoa coletiva  
  nome_empresa TEXT,
  nipc TEXT,
  
  -- Campos comuns
  morada TEXT,
  codigo_postal TEXT,
  localidade TEXT,
  distrito TEXT,
  descricao TEXT,
  logotipo_url TEXT,
  website TEXT,
  
  -- Saldo em X$ (moeda virtual da plataforma)
  saldo_xs DECIMAL(10,2) DEFAULT 0.00,
  
  -- Bónus em euros para descontar em comissões
  bonus_euros DECIMAL(10,2) DEFAULT 0.00,
  
  -- Código de indicação único para cada utilizador
  codigo_indicacao TEXT UNIQUE NOT NULL DEFAULT encode(gen_random_bytes(4), 'hex'),
  
  -- Quem indicou este utilizador
  indicado_por UUID REFERENCES public.profiles(id),
  
  -- Status da conta
  ativo BOOLEAN DEFAULT true,
  verificado BOOLEAN DEFAULT false,
  
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Criar tabela de transações em X$
CREATE TABLE public.transacoes_xs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  de_utilizador_id UUID REFERENCES public.profiles(id) NOT NULL,
  para_utilizador_id UUID REFERENCES public.profiles(id) NOT NULL,
  valor DECIMAL(10,2) NOT NULL,
  descricao TEXT NOT NULL,
  tipo TEXT CHECK (tipo IN ('compra', 'transferencia', 'credito', 'debito', 'bonus_indicacao')) NOT NULL,
  referencia_externa TEXT, -- Para referenciar anúncios, vouchers, etc.
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Criar tabela de linhas de crédito
CREATE TABLE public.linhas_credito (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  utilizador_id UUID REFERENCES public.profiles(id) NOT NULL,
  valor_emprestado DECIMAL(10,2) NOT NULL,
  valor_pago DECIMAL(10,2) DEFAULT 0.00,
  data_vencimento DATE NOT NULL,
  status TEXT CHECK (status IN ('ativo', 'liquidado', 'vencido')) DEFAULT 'ativo',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Ativar Row Level Security
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transacoes_xs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.linhas_credito ENABLE ROW LEVEL SECURITY;

-- Políticas RLS para profiles
CREATE POLICY "Utilizadores podem ver o próprio perfil" 
ON public.profiles 
FOR SELECT 
USING (user_id = auth.uid());

CREATE POLICY "Utilizadores podem ver perfis públicos" 
ON public.profiles 
FOR SELECT 
USING (ativo = true);

CREATE POLICY "Utilizadores podem atualizar o próprio perfil" 
ON public.profiles 
FOR UPDATE 
USING (user_id = auth.uid());

CREATE POLICY "Utilizadores podem inserir o próprio perfil" 
ON public.profiles 
FOR INSERT 
WITH CHECK (user_id = auth.uid());

-- Políticas RLS para transações
CREATE POLICY "Utilizadores podem ver as próprias transações" 
ON public.transacoes_xs 
FOR SELECT 
USING (de_utilizador_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid()) 
       OR para_utilizador_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid()));

CREATE POLICY "Sistema pode inserir transações" 
ON public.transacoes_xs 
FOR INSERT 
WITH CHECK (true);

-- Políticas RLS para linhas de crédito
CREATE POLICY "Utilizadores podem ver as próprias linhas de crédito" 
ON public.linhas_credito 
FOR SELECT 
USING (utilizador_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid()));

CREATE POLICY "Sistema pode inserir linhas de crédito" 
ON public.linhas_credito 
FOR INSERT 
WITH CHECK (true);

-- Função para criar perfil automaticamente ao registar
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = ''
AS $$
BEGIN
  INSERT INTO public.profiles (user_id, email, nome)
  VALUES (
    NEW.id, 
    NEW.email,
    COALESCE(NEW.raw_user_meta_data ->> 'nome', split_part(NEW.email, '@', 1))
  );
  RETURN NEW;
END;
$$;

-- Trigger para criar perfil automaticamente
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Função para atualizar timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers para atualizar timestamps
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_linhas_credito_updated_at
  BEFORE UPDATE ON public.linhas_credito
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();