-- Remover a política atual e criar uma mais simples
DROP POLICY IF EXISTS "Utilizadores podem editar os próprios anúncios" ON anuncios;

-- Criar uma política mais simples que usa diretamente o auth.uid()
CREATE POLICY "Utilizadores podem editar os próprios anúncios" 
ON anuncios 
FOR UPDATE 
USING (
  utilizador_id IN (
    SELECT id 
    FROM profiles 
    WHERE user_id = auth.uid()
  )
);

-- Verificar se há problemas com a autenticação no Supabase
-- Configurar para auto-confirmar emails para facilitar testes
UPDATE auth.config SET 
  enable_signup = true,
  enable_confirmations = false
WHERE id = 1;