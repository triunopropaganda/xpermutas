-- Criar função para alterar disponibilidade do anúncio
-- Esta função faz a verificação de propriedade internamente
CREATE OR REPLACE FUNCTION public.toggle_anuncio_disponibilidade(
  anuncio_id UUID,
  novo_status BOOLEAN,
  utilizador_profile_id UUID
)
RETURNS JSON AS $$
DECLARE
  anuncio_record RECORD;
  result JSON;
BEGIN
  -- Verificar se o anúncio existe e pertence ao utilizador
  SELECT * INTO anuncio_record 
  FROM anuncios 
  WHERE id = anuncio_id AND utilizador_id = utilizador_profile_id;
  
  IF NOT FOUND THEN
    result := json_build_object(
      'success', false,
      'error', 'Anúncio não encontrado ou não tem permissão para editá-lo'
    );
    RETURN result;
  END IF;
  
  -- Atualizar a disponibilidade
  UPDATE anuncios 
  SET disponivel = novo_status, updated_at = now()
  WHERE id = anuncio_id AND utilizador_id = utilizador_profile_id;
  
  -- Retornar sucesso
  result := json_build_object(
    'success', true,
    'message', CASE WHEN novo_status THEN 'Anúncio reativado' ELSE 'Anúncio pausado' END
  );
  
  RETURN result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;