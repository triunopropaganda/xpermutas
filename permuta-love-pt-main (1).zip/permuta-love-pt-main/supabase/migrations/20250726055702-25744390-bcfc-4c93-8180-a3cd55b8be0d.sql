-- Criar função para processar transações de forma segura (corrigida)
CREATE OR REPLACE FUNCTION public.processar_transacao_xs(
  p_tipo TEXT,
  p_valor NUMERIC,
  p_de_utilizador_id UUID,
  p_para_utilizador_id UUID DEFAULT NULL,
  p_anuncio_id UUID DEFAULT NULL,
  p_descricao TEXT DEFAULT '',
  p_referencia_externa TEXT DEFAULT NULL
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_transacao_id UUID;
  v_saldo_atual NUMERIC;
BEGIN
  -- Gerar ID para a transação
  v_transacao_id := gen_random_uuid();
  
  -- Verificar saldo para operações que requerem fundos
  IF p_tipo IN ('compra', 'transferencia') THEN
    SELECT saldo_xs INTO v_saldo_atual 
    FROM profiles 
    WHERE id = p_de_utilizador_id;
    
    IF v_saldo_atual < p_valor THEN
      RAISE EXCEPTION 'Saldo insuficiente. Saldo atual: % X$', v_saldo_atual;
    END IF;
    
    -- Debitar do remetente
    UPDATE profiles 
    SET saldo_xs = saldo_xs - p_valor, updated_at = now()
    WHERE id = p_de_utilizador_id;
    
    -- Creditar no destinatário (se aplicável)
    IF p_para_utilizador_id IS NOT NULL THEN
      UPDATE profiles 
      SET saldo_xs = saldo_xs + p_valor, updated_at = now()
      WHERE id = p_para_utilizador_id;
    END IF;
    
  -- Para depósitos e vendas, apenas creditar
  ELSIF p_tipo IN ('deposito', 'venda') THEN
    UPDATE profiles 
    SET saldo_xs = saldo_xs + p_valor, updated_at = now()
    WHERE id = COALESCE(p_para_utilizador_id, p_de_utilizador_id);
  END IF;
  
  -- Registrar a transação
  INSERT INTO transacoes_xs (
    id,
    tipo,
    valor,
    de_utilizador_id,
    para_utilizador_id,
    descricao,
    referencia_externa,
    created_at
  ) VALUES (
    v_transacao_id,
    p_tipo,
    p_valor,
    p_de_utilizador_id,
    COALESCE(p_para_utilizador_id, p_de_utilizador_id),
    p_descricao,
    p_referencia_externa,
    now()
  );
  
  RETURN v_transacao_id;
END;
$$;