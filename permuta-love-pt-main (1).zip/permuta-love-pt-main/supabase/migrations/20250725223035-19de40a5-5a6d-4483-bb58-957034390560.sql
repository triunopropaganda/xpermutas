-- Verificar e corrigir a política RLS de UPDATE para anuncios
-- A política atual verifica se utilizador_id existe na tabela profiles onde user_id = auth.uid()
-- Vamos criar uma política mais direta que verifica se o utilizador é o dono do anúncio

DROP POLICY IF EXISTS "Utilizadores podem editar os próprios anúncios" ON anuncios;

CREATE POLICY "Utilizadores podem editar os próprios anúncios" 
ON anuncios 
FOR UPDATE 
USING (
  utilizador_id = (
    SELECT id 
    FROM profiles 
    WHERE user_id = auth.uid()
    LIMIT 1
  )
);