-- Adicionar foreign key constraint entre anuncios e profiles
ALTER TABLE public.anuncios 
ADD CONSTRAINT fk_anuncios_utilizador 
FOREIGN KEY (utilizador_id) REFERENCES public.profiles(id) ON DELETE CASCADE;