import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface TransacaoRequest {
  tipo: 'compra' | 'venda' | 'deposito' | 'transferencia';
  valor: number;
  para_utilizador_id?: string;
  anuncio_id?: string;
  descricao: string;
  referencia_externa?: string;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Autenticar usuário
    const authHeader = req.headers.get('Authorization')!;
    const token = authHeader.replace('Bearer ', '');
    const { data: userData } = await supabaseClient.auth.getUser(token);
    const user = userData.user;

    if (!user) {
      throw new Error('Utilizador não autenticado');
    }

    // Buscar perfil do usuário
    const { data: profile, error: profileError } = await supabaseClient
      .from('profiles')
      .select('id, saldo_xs')
      .eq('user_id', user.id)
      .single();

    if (profileError || !profile) {
      throw new Error('Perfil não encontrado');
    }

    const body: TransacaoRequest = await req.json();
    const { tipo, valor, para_utilizador_id, anuncio_id, descricao, referencia_externa } = body;

    // Validações
    if (valor <= 0) {
      throw new Error('Valor deve ser positivo');
    }

    console.log(`Processando transação: ${tipo} - Valor: ${valor} X$ - Utilizador: ${profile.id}`);

    // Iniciar transação na base de dados
    const { data, error } = await supabaseClient.rpc('processar_transacao_xs', {
      p_tipo: tipo,
      p_valor: valor,
      p_de_utilizador_id: profile.id,
      p_para_utilizador_id: para_utilizador_id || null,
      p_anuncio_id: anuncio_id || null,
      p_descricao: descricao,
      p_referencia_externa: referencia_externa || null
    });

    if (error) {
      console.error('Erro ao processar transação:', error);
      throw new Error(error.message || 'Erro ao processar transação');
    }

    console.log('Transação processada com sucesso:', data);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Transação processada com sucesso',
        transacao_id: data
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );

  } catch (error) {
    console.error('Erro na edge function:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message || 'Erro interno do servidor' 
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      }
    );
  }
});